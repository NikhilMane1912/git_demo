package presentation;

import integretion.AppServiceActivator;
import integretion.ConfigReader;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bussiness.dispatcher.MainDispatcher;

import presentation.filter.FilterChainFactory;
import presentation.filter.FilterConstants;
import presentation.filter.FilterContext;
import presentation.filter.FilterMgr;

import service.AppContext;

public class BaseServlet extends HttpServlet{

	private FilterMgr filterMgr= null;
	private AppContext appContext = null;
	
	
	
	public AppContext getAppContext() {
		return appContext;
	}

	public void setAppContext(AppContext appContext) {
		this.appContext = appContext;
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response){
		FilterContext filterContext = getFilterContext(request,response);
		
		String result = filterMgr.processFilters(FilterConstants.PRE_REQUEST, filterContext);
	
		if(result==null){
			result = MainDispatcher.dispatch(filterContext.retriveStateMgr());
		}
		filterContext.setView(result);
		
		filterMgr.processFilters(FilterConstants.POST_REQUEST, filterContext);
	}
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		processRequest(request,response);
	}
	
	
	protected FilterContext getFilterContext(HttpServletRequest request, HttpServletResponse response){
		 FilterContext filterContext = new FilterContext();
         filterContext.setRequest(request);
         filterContext.setResponse(response);
         filterContext.setAppContext(getAppContext());
         filterContext.setServletContext(getServletContext());

         return filterContext;
	}

	
	/*
	 *  need to do :
	 *  1. read config file 
	 *  2. init filter Mgr
	 */
	
	@Override
	public void init() throws ServletException {
		
		super.init();
		
		// 1. read config file
		
		//get configDir from web.xml first
		String configDir = getServletConfig().getInitParameter("configDir");
		
		AppContext context = null;
		
		AppServiceActivator activator = new AppServiceActivator();
		context = activator.initializeApplicationContext(configDir);
		
		setAppContext(context);
		
		// 2. init filter Mgr
		filterMgr = new FilterMgr(new FilterChainFactory());
	}

}
