package integretion.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBAccessor {

	protected transient Connection conn = null;
    protected transient PreparedStatement pstmt = null;

    
    public DBAccessor(Connection theConnection) {
        this.conn = theConnection;
    }

    
    //------------------~ Methods ~------------------
    
    /**
     * Gets the PreparedStatement.
     */
    protected PreparedStatement getPreparedStatement(Connection conn, String sql){
    	PreparedStatement pstmt = null;
    	try {
			pstmt = conn.prepareStatement(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	return pstmt;
    }
    
    
    
    /**
     * Return a result set object from the given query with parameters.
     */
    public ResultSet executeQuery(String sql, String[] sqlParams){
    	ResultSet result = null;
    	
    	 if (null == sql) {
    		 System.out.println("Error! : sql is null while running executeQuery");
    		 return null;
    	 }
    	 
    	 try{
	    	 this.pstmt = getPreparedStatement(this.conn,sql);
	    	 
	    	 if (null != sqlParams) {
	             for (int i = 0; i < sqlParams.length; i++)
	                 this.pstmt.setObject(i + 1, sqlParams[i]);
	         }
	    	 
	    	 result = this.pstmt.executeQuery();
    	 }catch(SQLException e){
    		 
    	 }
    	 
    	 return result;
    }
    
    
    
    
    /**
     * Close and release the connection object.
     */
    public void release(){
    	close(this.pstmt);
    	close(this.conn);
    }
    
    
    /**
     * Close the active result set reference object.
     */
    
    public void close(ResultSet resultSet){
    	
    	if(resultSet!=null){
    		try {
				resultSet.close();
				close(this.pstmt);
				resultSet = null;
				this.pstmt = null;
			} 
    		catch (SQLException e) {
				e.printStackTrace();
			}
    	}
    }

    /**
     * Close the active prepared statement.
     */
    protected void close(PreparedStatement preparedStatement){
    	try{
    		if(preparedStatement!=null){
    			preparedStatement.close();
    		}
    	}
    	catch(SQLException e){
    		e.printStackTrace();
		}
    }
    
    
    /**
     * Close the active connection object.
     */
    protected void close(Connection connection){
    	try{
    		if(connection!=null){
    			connection.close();
    		}
    	}
    	catch(SQLException e){	
    		e.printStackTrace();
		}
    }
    
    
    
    
}
