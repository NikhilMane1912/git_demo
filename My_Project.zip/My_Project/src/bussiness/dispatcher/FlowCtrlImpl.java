package bussiness.dispatcher;

import bussiness.model.CategoryModel;
import bussiness.model.ProductListModel;
import service.StateMgr;

public class FlowCtrlImpl extends AbstractBaseFlowCtrl{

	@Override
	protected boolean isScreenFlowUpdatedRequired(String CurrentID) {
		return (CurrentID.equals("CATEGORY")|| CurrentID.contains("LIST"));
	}

	@Override
	protected void updateScreenFlow(StateMgr StateMgr) {
		
		String key = null;
		
		if(this.currentMainID.equals("CATEGORY")){
			CategoryModel categoryModel = StateMgr.getBusinessContext().getCategoryModel();
			if(categoryModel==null){
				System.out.println("ERROR! : updateScreenFlow while categoryModel is null");
				return;
			}
			String selectedType = categoryModel.getSelectedType();
			if(selectedType==null){
				System.out.println("ERROR! : updateScreenFlow while selectedType is null");
				return;
			}
			
			key = selectedType.toUpperCase()+"LIST";
			
			
		}
		else{
			ProductListModel model = StateMgr.getBusinessContext().getProductListModel();
			if(model==null){
				System.out.println("ERROR! : updateScreenFlow while model is null");
				return;
			}
			String selectedProduct = model.getSelectedProduct();
			if(selectedProduct==null){
				System.out.println("ERROR! : updateScreenFlow while selectedProduct is null");
				return;
			}
			
			key = selectedProduct.toUpperCase();
		}
		
		String currentID = this.getCurrentMainID();
		
		int currentIndex = this.screenFlow.indexOf(currentID);
		this.screenFlow.add(currentIndex+1,key);
		
	}



}
