package bussiness.model;

public class ReportModel {

	private String reportURL = null;

	public String getReportURL() {
		return reportURL;
	}

	public void setReportURL(String reportURL) {
		this.reportURL = reportURL;
	}
	
}
