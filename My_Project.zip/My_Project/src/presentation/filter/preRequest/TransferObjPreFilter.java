package presentation.filter.preRequest;

import java.util.Map;

import presentation.filter.AbstractFilter;
import presentation.filter.FilterContext;
import presentation.helper.TransferObjectHelper;

public class TransferObjPreFilter extends AbstractFilter{

	@Override
	public String process(FilterContext filterContext) {
		Map map = filterContext.getRequest().getParameterMap();
		
		TransferObjectHelper.MergeParameterIntoTransferObject(filterContext.retriveStateMgr(), map);
		
		return null;
	}

}
