package service.to;

public class UserProfileTO extends BaseTO{

	private int userID = -1;
	
	private String name = null;
	private String gender = null;
	private String password = null;
	
	private String isInfoNeedSupplement = null;
	
	public String isInfoNeedSupplement() {
		return isInfoNeedSupplement;
	}
	public void setInfoNeedSupplement(String isInfoNeedSupplement) {
		this.isInfoNeedSupplement = isInfoNeedSupplement;
	}
	
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
