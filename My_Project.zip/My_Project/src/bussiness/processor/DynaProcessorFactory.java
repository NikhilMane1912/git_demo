package bussiness.processor;

public class DynaProcessorFactory extends AbstractDynaProcessorFactory{

}
