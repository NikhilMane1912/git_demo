package bussiness.dispatcher;

import bussiness.action.ActionIf;
import service.StateMgr;

public class CurrentScreenDispatcher extends AbstractBaseDispatcher{

	@Override
	protected String dispatch(StateMgr stateMgr) {
		String destActionID = null;
		 
		destActionID = processCurrentScreen(stateMgr);
		
		String viewID = stateMgr.getViewMap().get(destActionID);
		 
		return viewID; 

	}
	
	private String processCurrentScreen(StateMgr stateMgr) {
		String currentID = stateMgr.getFlowCtrl().getCurrentMainID();
		
		String operationToPerform = stateMgr.getTransferObject().getProcessOtherID();
		
		ActionIf action = null;
		
		action = getActionIf(stateMgr,currentID);
		action.processOther(stateMgr, operationToPerform);
		
		return currentID;
	}

}
