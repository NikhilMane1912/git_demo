package presentation;

public class Constants {
	public final static String SESSION_STATE_MGR = "StateMgr";
	
	public final static String REQUEST_CURRENT_ACTION_ID = "currentActionID";
	
	
	
	// Flow Ctrl
	public final static String FLOW_CTRL_Class_NAME = "flowControlClass";
	public final static String USERPROFILE = "USERPROFILE";
	public final static String SUPPLEMENT = "SUPPLEMENT";
	public final static String CATEGORY = "CATEGORY";
	public final static String PRODUCTDETAILS = "PRODUCTDETAILS";
	public final static String PAYMENT = "PAYMENT";
	
	
	// Factory type
	public final static String FACTORY_TYPE_TO = "to";
	public final static String FACTORY_TYPE_ACTION = "action";
	public final static String FACTORY_TYPE_PROCESSOR = "processor";
	public final static String FACTORY_TYPE_INITIALISER = "initialiser";
	public final static String FACTORY_TYPE_VALIDATOR = "validator";
	public final static String FACTORY_TYPE_DB = "db";
	
	// Dispatcher
	public final static String DISPATCHER_FIRST_SCREEN = "firstscreen";
	public final static String DISPATCHER_FORWARD_SCREEN = "forward";
	public final static String DISPATCHER_BACKWARD_SCREEN = "backward";
	public final static String DISPATCHER_CURRENT_SCREEN = "current";
	public final static String DISPATCHER_NEWWINDOW_SCREEN = "NewWindow";
}
