package service.to;

public class ReportTO extends BaseTO{

	private String targetURL = null;
	public String getTargetURL() {
		return targetURL;
	}
	public void setTargetURL(String targetURL) {
		this.targetURL = targetURL;
	}
	
}
