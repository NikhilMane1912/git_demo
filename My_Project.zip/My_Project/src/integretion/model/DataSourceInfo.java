package integretion.model;

import java.util.HashMap;

public class DataSourceInfo {

	private String id = null;
	private String name = null;
	private String type = null;
	
	private HashMap<String,String> dsparamMap = new HashMap<String,String>();
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public void setToParamMap(String key,String value){
		dsparamMap.put(key, value);
	}
	
	public String getFromParamMap(String key){
		return dsparamMap.get(key);
	}
	
	public HashMap<String,String> getDsParamMap(){
		return dsparamMap;
	}

}
