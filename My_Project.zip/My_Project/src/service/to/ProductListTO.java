package service.to;

import java.util.ArrayList;

public class ProductListTO extends BaseTO{

	private ArrayList<String> lists = null;
	
	private String selectedProduct = null;


	public ArrayList<String> getList() {
		return lists;
	}

	public void setList(ArrayList<String> alist) {
		this.lists = alist;
	}

	public String getSelectedProduct() {
		return selectedProduct;
	}

	public void setSelectedProduct(String product) {
		this.selectedProduct = product;
	}
}
