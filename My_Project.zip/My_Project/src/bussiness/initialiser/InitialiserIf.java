package bussiness.initialiser;

import service.StateMgr;

public interface InitialiserIf {

	/**
     * Set the current initialiser ID.
    */
    void setID(String theID);

    /**
     * Return the current initialiser ID.
     */
    String getID();
    
    
    
    /**
     * Perform default initialisation process.
     */
    void initialise(StateMgr mgr);
    

    /**
     * Perform customize initialisation process identify by the initialiseOther ID.
     */
    void initialiseOther(StateMgr mgr, String initialiseOtherID);
    
}
