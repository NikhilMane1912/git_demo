package integretion.persistence;

import java.sql.Connection;

public interface ConnectionHandlerIf {

	/**
     * Return the active connection instance.
     */
    Connection getConnection();
}
