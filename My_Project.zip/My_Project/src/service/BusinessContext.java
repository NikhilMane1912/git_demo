package service;

import bussiness.model.CategoryModel;
import bussiness.model.ProductIf;
import bussiness.model.ProductListModel;
import bussiness.model.ReportModel;
import bussiness.model.UserProfileModel;
import service.to.BaseTO;

public class BusinessContext {

	private BaseTO baseTO = null;
	public BaseTO getBaseTO() {
		return baseTO;
	}
	public void setBaseTO(BaseTO baseTO) {
		this.baseTO = baseTO;
	}
	
	
	
	private UserProfileModel userProfile = null;
	public UserProfileModel getUserProfile() {
		return userProfile;
	}
	public void setUserProfile(UserProfileModel userProfile) {
		this.userProfile = userProfile;
	}
	
	
	private CategoryModel categoryModel = null;
	public CategoryModel getCategoryModel() {
		return categoryModel;
	}
	public void setCategoryModel(CategoryModel categoryModel) {
		this.categoryModel = categoryModel;
	}
	
	
	private ProductListModel productListModel = null;
	public ProductListModel getProductListModel() {
		return productListModel;
	}
	public void setProductListModel(ProductListModel productDetailsModel) {
		this.productListModel = productDetailsModel;
	}
	
	
	private ProductIf selectedProduct = null;
	public ProductIf getSelectedProduct() {
		return selectedProduct;
	}
	public void setSelectedProduct(ProductIf selectedProduct) {
		this.selectedProduct = selectedProduct;
	}
	
	
	private ReportModel rptModel = null;
	public ReportModel getRptModel() {
		return rptModel;
	}
	public void setRptModel(ReportModel rptModel) {
		this.rptModel = rptModel;
	}
	
	
	
}
