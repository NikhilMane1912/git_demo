package bussiness.validator;

public class DynaValidatorFactory extends AbstractDynaValidatorFactory{

}
