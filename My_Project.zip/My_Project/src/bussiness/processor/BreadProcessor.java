package bussiness.processor;

import bussiness.model.food.BreadModel;
import service.StateMgr;
import service.to.BreadTO;

public class BreadProcessor extends BaseProcessor{

	@Override
	protected void populateBeanFromModel(StateMgr mgr) {
		BreadModel model = (BreadModel)mgr.getBusinessContext().getSelectedProduct();
		BreadTO to = (BreadTO)createBean(mgr);
		
		to.setProductName(model.getProductName());
		to.setProductPrice(model.getProductPrice());
		to.setUsage(model.getUsage());
		
		mgr.setTransferObject(to);
		
	}

	@Override
	protected void populateModelFromBean(StateMgr mgr) {
		BreadModel model = (BreadModel)mgr.getBusinessContext().getSelectedProduct();
		BreadTO to = (BreadTO)mgr.getTransferObject();
		model.setProductName(to.getProductName());
		model.setProductPrice(to.getProductPrice());
		model.setUsage(to.getUsage());
	}

	@Override
	public void processOther(StateMgr mgr, String processOtherID) {
		// TODO Auto-generated method stub
		
	}

}
