package bussiness.processor;

public abstract class AbstractDynaProcessorFactory extends AbstractProcessorFactory{

	
	protected ProcessorIf create(String processorName){
		ProcessorIf result = null;
		
		if(processorName==null){
			System.out.println("processorName should not be null when create ProcessorIf");
			return null;
		}
		
		try{
			result = (ProcessorIf) Class.forName(processorName).newInstance();
		}catch(Exception e){
			
		}
		
		return result;
		 
	}
}
