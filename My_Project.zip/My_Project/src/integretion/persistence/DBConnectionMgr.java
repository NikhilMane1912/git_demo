package integretion.persistence;


import integretion.model.DataSourceInfo;

import java.util.HashMap;
import java.util.Iterator;

import service.StateMgr;

public class DBConnectionMgr {
	
	HashMap<String,DBAccessor> dbAccessorMap = new 
			HashMap<String,DBAccessor>();
	
	
	public void initConnections(StateMgr stateMgr){
		HashMap<String,DataSourceInfo> DataSourceInfoMap = 
				stateMgr.getApplicationContext().getDataSourceInfoMap();
		
		DataSourceInfo info = null;
        DBAccessor accessor = null;
        
        //-----------use the factory to create the accessor -----------
        DBConnectionFactory dbConnFactory = stateMgr.getDBConnectionFactory();
        
        for(Iterator iter = DataSourceInfoMap.values().iterator();iter.hasNext();){
        	info = (DataSourceInfo)iter.next();
        	accessor = dbConnFactory.createDBAccessor(info);
        	this.dbAccessorMap.put(info.getId(), accessor);
        }

	}
	
	
	 /**
     * Release all the connections
     */
	public void releaseConnections(){
		
		if(this.dbAccessorMap==null)
			return;
		
		DBAccessor accessor = null;
        String sourceID = null;
		
		for (Iterator itr = this.dbAccessorMap.keySet().iterator(); itr.hasNext();) {
			sourceID = (String) itr.next();
            accessor = (DBAccessor) this.dbAccessorMap.get(sourceID);
            accessor.release();
		}
		
		this.dbAccessorMap.clear();
	}
	
	 /**
     * Return the DB Accessor from the repository.
     */
	public DBAccessor getDBAccessor(String id){
		DBAccessor result = null;
        result = this.dbAccessorMap.get(id);
        return result;
	}
}
