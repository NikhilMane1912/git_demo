package bussiness.initialiser;

import java.util.HashMap;

public abstract class AbstractInitialiserFactory {

	private HashMap<String,InitialiserIf> initialiserMap = 
			new HashMap<String,InitialiserIf>();
	
	public InitialiserIf create(String initialiserName, boolean isCached){
		InitialiserIf action = null;
		
		if(isCached){
			if(initialiserMap.containsKey(initialiserName)){
				return initialiserMap.get(initialiserName);
			}
			else{
				synchronized(initialiserMap){
					if(initialiserMap.containsKey(initialiserName)){
						return initialiserMap.get(initialiserName);
					}
					action = create(initialiserName);
					if(action==null){
						System.out.println("create action fail!");
					}
					initialiserMap.put(initialiserName, action);
				}
			}
			
		}
		else{
			action = create(initialiserName);
		}
		return action;
	}
	
	protected abstract InitialiserIf create(String initialiserName);
}
