package bussiness.dispatcher;

import bussiness.action.ActionIf;
import service.StateMgr;

public class NewWindowDispatcher extends AbstractBaseDispatcher{

	@Override
	protected String dispatch(StateMgr stateMgr) {
		
		String destActionID = null;
		
		destActionID = stateMgr.getTransferObject().getTargetActionID();
		initialiseScreen(stateMgr,destActionID);
		
		stateMgr.getFlowCtrl().setCurrentMainID(destActionID);
		
		String viewID = stateMgr.getViewMap().get(destActionID);
		 
		 return viewID;
	}
	
	private void initialiseScreen(StateMgr statMgr, String destID){
		ActionIf action = getActionIf(statMgr,destID);
		action.initialise(statMgr);
	}

}
