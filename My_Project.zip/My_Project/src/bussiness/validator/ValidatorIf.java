package bussiness.validator;

import service.StateMgr;

public interface ValidatorIf {

	 void setID(String theID);
	 String getID();
	 
	 void validate(StateMgr mgr);
	 void validateOther(StateMgr mgr, String validatorOtherID);
}
