package bussiness.processor;

import service.StateMgr;

public abstract class AbstractBaseProcessor implements ProcessorIf{

	private String id = null;
    public void setID(String anID) {
        this.id = anID;
    }
    public String getID() {
        return this.id;
    }
    
    /**
     * Initialise the process event.
     */
    public abstract void initialise(StateMgr mgr);
    
    
    /**
     * Process the default event for current request.
     */
    public abstract void process(StateMgr stateMgr);
    

    /**
     * Process alternate event that may be triggered by the request.
     */
    public abstract void processOther(StateMgr mgr, String processOtherID);
    
    
    /**
     * Retrieve the response from the process event.
     */
    public abstract void retrieve(StateMgr mgr);
    
    
    /**
     * Validates the transfer object. This is meant for complete validation.
     */
    public abstract void validate(StateMgr mgr);
}
