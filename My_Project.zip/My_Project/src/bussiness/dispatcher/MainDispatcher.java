package bussiness.dispatcher;

import service.StateMgr;


/**
 * This class will act as the main facade to the core SQS engine. All communications from presentation layer must be routed to this class'
 * <code>dispatch()</code> method.
*/
public class MainDispatcher {

	public static String dispatch(StateMgr stateMgr){
		//----- Get the dispatching type
		String direction = stateMgr.getTransferObject().getDirection();
		
		AbstractBaseDispatcher dispatcher = stateMgr.getDispatcher(direction);
		
		return dispatcher.dispatch(stateMgr);
	}
}
