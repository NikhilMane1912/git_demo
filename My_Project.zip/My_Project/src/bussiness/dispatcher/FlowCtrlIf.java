package bussiness.dispatcher;

import service.StateMgr;

public interface FlowCtrlIf {

	
	/**
     * Initialises the work flow
     */
    void initialise();
	
	String getFirstID();
	
	 /**
     * Gets the next ID within the flow
     */
	String getNextID(String currentID, StateMgr stateMgr);
	
	/**
     * Gets the previous ID within the flow
     */
	String getPreviousID(String currentID, StateMgr stateMgr);
	
	
	 /**
     * Sets the current MainID.
     */
    void setCurrentMainID(String currentMainID);


    /**
     * Gets the current MainID
     */
    String getCurrentMainID();
    
    
    /**
     * Sets the BranchID to go to.
     */
    void setBranchID(String branchID);


    /**
     * Gets the current BranchID
     */
    String getBranchID();
    
	
}
