package integretion;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import service.AppContext;

public class BizConfigHandler extends DefaultHandler{
	
	private AppContext context = null;
	
	public BizConfigHandler(AppContext acontext){
		this.context = acontext;
	}
	
	/**
     *      接收文档的开始的通知。
     */
	@Override
	public void startDocument() throws SAXException {
		
	}
	
	
	 /**
     *     接收元素开始的通知。
     *  namespaceURI:元素的命名空间
     *  localName:元素的本地名称（不带前缀）
     *  qName:元素的限定名（带前缀）
     *  atts:元素的属性集合
     *  
     *  注意：
     *  	由于有些环境不一样，有时候第二个参数有可能为空，
     *  	所以可以使用第三个参数
     */
	@Override
	public void startElement(String uri, String qName, String localName, Attributes attributes) 
			throws SAXException {
		if(localName.equals("map")){
			String id = attributes.getValue("id");
			String view= attributes.getValue("view");
			String bean= attributes.getValue("bean");
			String action= attributes.getValue("action");
			String initialiser= attributes.getValue("initialiser");
			String validator= attributes.getValue("validator");
			String processor= attributes.getValue("processor");
			
			this.context.getViewMap().put(id, view);
			this.context.getBeanMap().put(id, bean);
			this.context.getActionMap().put(id, action);
			this.context.getInitialiserMap().put(id, initialiser);
			this.context.getValidatorMap().put(id, validator);
			this.context.getProcessorMap().put(id, processor);
		}
		
	}
	
	
	 /**
     *      接收文档的结尾的通知。
     *     uri:元素的命名空间
     *     localName:元素的本地名称（不带前缀）
     *     name:元素的限定名（带前缀）
     */
	@Override
	public void endElement(String uri, String qName, String localName)
			throws SAXException {
	}
}
