package bussiness.validator;

public abstract class BaseValidator extends AbstractBaseValidator{

}
