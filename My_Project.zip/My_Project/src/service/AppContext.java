package service;

import integretion.model.DataSourceInfo;
import integretion.model.FactoryInfo;
import integretion.persistence.DBConnectionFactory;

import java.util.HashMap;

import bussiness.action.AbstractActionFactory;
import bussiness.dispatcher.AbstractBaseDispatcher;
import bussiness.initialiser.AbstractInitialiserFactory;
import bussiness.processor.AbstractProcessorFactory;
import bussiness.validator.AbstractValidatorFactory;

import service.to.AbstractTOFactory;

public class AppContext {
	
	
	/*
	 * 	ConfigMap use to store data which is read from 
	 * 	appconfig.xml of element <config> 
	 * 	one <config> element is one <key,value> pair 
	 * 	in this ConfigMap!
	 */
	private HashMap<String,String> configMap = null;
	
	private HashMap<String,DataSourceInfo> DataSourceInfoMap = null;
	
	
	// this part use to store data which is read from bizConfig.xml
	// every map element has 
	// 	[id,description,view,bean,action,initialiser,validator,processor]
	// so id is the key ..
	private HashMap<String,String> viewMap = null;
	private HashMap<String,String> beanMap = null;
	private HashMap<String,String> actionMap = null;
	private HashMap<String,String> initialiserMap = null;
	private HashMap<String,String> validatorMap = null;
	private HashMap<String,String> processorMap = null;
	
	
	//getter method for these map
	public HashMap<String,String> getViewMap(){
		return viewMap;
	}
	public HashMap<String,String> getBeanMap(){
		return beanMap;
	}
	public HashMap<String,String> getActionMap(){
		return actionMap;
	}
	public HashMap<String,String> getInitialiserMap(){
		return initialiserMap;
	}
	public HashMap<String,String> getValidatorMap(){
		return validatorMap;
	}
	public HashMap<String,String> getProcessorMap(){
		return processorMap;
	}
	
	
	// constructor
	public AppContext(){
		this.configMap = new HashMap<String,String>();
		this.DataSourceInfoMap = new HashMap<String,DataSourceInfo>();
		this.factoryMap = new HashMap<String,FactoryInfo>();
		this.beanMap = new HashMap<String,String>();
		this.dispatcherMap = new HashMap<String,AbstractBaseDispatcher>();
		this.toMap = new HashMap<String,String>();
		
		this.viewMap = new HashMap<String,String>();
		this.beanMap = new HashMap<String,String>();
		this.actionMap = new HashMap<String,String>();
		this.initialiserMap = new HashMap<String,String>();
		this.validatorMap = new HashMap<String,String>();
		this.processorMap = new HashMap<String,String>();
	}
	
	
	// ConfigMap
	public void stroeToConfigMap(String key,String value){
		configMap.put(key, value);
	}
	
	public String getFromConfigMap(String key){
		String result = configMap.get(key);
		return result;
	}
	
	
	// dataSource Info
	public void stroeToDataSourceInfoMap(String id,DataSourceInfo info){
		DataSourceInfoMap.put(id, info);
	}
	public DataSourceInfo getFromDataSourceInfoMap(String id){
		return DataSourceInfoMap.get(id);
	}
	public HashMap<String,DataSourceInfo> getDataSourceInfoMap(){
		return DataSourceInfoMap;
	}
	
	// DBConnectionFactory
	private DBConnectionFactory dbConnFactory = null;
	public DBConnectionFactory getDBConnectionFactory() {
		return this.dbConnFactory;
	}
	public void setDBConnectionFactory(DBConnectionFactory dbConnFactory) {
	        this.dbConnFactory = dbConnFactory;
	}

	
	// AbstractTOFactory
	private AbstractTOFactory toFactory = null;
	
	public AbstractTOFactory getTOFactory() {
		return this.toFactory;
	}
	public void setTOFactory(AbstractTOFactory factory){
		this.toFactory = factory;
	}
	
	
	private HashMap<String,String> toMap = null;
	public HashMap<String,String> getTOMap(){
		return this.toMap;
	}
	
	/*
	 *  factoryMap is <id,FactoryInfo> struct
	 */
	private HashMap<String,FactoryInfo> factoryMap = null;
	public HashMap<String,FactoryInfo> getFactoryMap(){
		return factoryMap;
	}
	public void storeToFactoryMap(FactoryInfo info){
		factoryMap.put(info.getType(),info);
	}
	
	
	//---  Dispatcher ---
	// use to store specific Dispatchers
	private HashMap<String,AbstractBaseDispatcher> dispatcherMap = null;
	public HashMap<String,AbstractBaseDispatcher> getDispatcherMap(){
		return this.dispatcherMap;
	}
	public void setToDispatcherMap(String dispatcherName,AbstractBaseDispatcher dispatcher){
		this.dispatcherMap.put(dispatcherName, dispatcher);
	}
	//---  Dispatcher ---
	
	
	
	//	--  Action Factory --
	private AbstractActionFactory actionFactory = null;
	public AbstractActionFactory getActionFactory(){
		return actionFactory;
	}
	public void setActionFactory(AbstractActionFactory factory){
		this.actionFactory = factory;
	}
//	--  Action Factory --
	
	
//	--  Processor Factory --
	private AbstractProcessorFactory processorFactory = null;
	public AbstractProcessorFactory getProcessorFactory(){
		return processorFactory;
	}
	public void setProcessorFactory(AbstractProcessorFactory factory){
		this.processorFactory = factory;
	}
//	--  Processor Factory --
	
//	--  Initialiser Factory --
	private AbstractInitialiserFactory initialiserFactory = null;
	public AbstractInitialiserFactory getInitialiserFactory(){
		return initialiserFactory;
	}
	public void setInitialiserFactory(AbstractInitialiserFactory factory){
		this.initialiserFactory = factory;
	}
//	--  Initialiser Factory --
	
	
//	--  Validator Factory --
	private AbstractValidatorFactory validatorFactory = null;
	public AbstractValidatorFactory getValidatorFactory(){
		return validatorFactory;
	}
	public void setValidatorFactory(AbstractValidatorFactory factory){
		this.validatorFactory = factory;
	}
//	--  Validator Factory --
	
	
}
