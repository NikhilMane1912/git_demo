package presentation.filter;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import presentation.Constants;

import service.AppContext;
import service.StateMgr;

public class FilterContext {

	private boolean isStoreStateMgrInSession = true;
	
	private AppContext appContext = null;
    private HttpServletRequest request = null;
    private HttpServletResponse response = null;
    private ServletContext servletContext = null;
    private String view = null;
    
    
	public boolean isStoreStateMgrInSession() {
		return isStoreStateMgrInSession;
	}
	public void setStoreStateMgrInSession(boolean isStoreStateMgrInSession) {
		this.isStoreStateMgrInSession = isStoreStateMgrInSession;
	}
	
	public AppContext getAppContext() {
		return appContext;
	}
	public void setAppContext(AppContext appContext) {
		this.appContext = appContext;
	}
	
	public HttpServletRequest getRequest() {
		return request;
	}
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}
	
	public HttpServletResponse getResponse() {
		return response;
	}
	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}
	
	public ServletContext getServletContext() {
		return servletContext;
	}
	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}
	
	public String getView() {
		return view;
	}
	public void setView(String view) {
		this.view = view;
	}
	
	
	public void storeStateMgr(StateMgr stateMgr) {
		if(isStoreStateMgrInSession()){
			getRequest().getSession().setAttribute(Constants.SESSION_STATE_MGR, stateMgr);
		}
		else
			getServletContext().setAttribute(Constants.SESSION_STATE_MGR, stateMgr);
	}
    
	
	public StateMgr retriveStateMgr() {
		 StateMgr stateMgr = null;
		 Object tmp = null;
		 if(isStoreStateMgrInSession()){
			 tmp = getRequest().getSession().getAttribute(Constants.SESSION_STATE_MGR);
		 }
		 else
			 tmp = getServletContext().getAttribute(Constants.SESSION_STATE_MGR);
		 
		 if(tmp==null){
			 
		 }
		 
		 stateMgr = (StateMgr)tmp;
		 
		 return stateMgr;
	}
    
    
}
