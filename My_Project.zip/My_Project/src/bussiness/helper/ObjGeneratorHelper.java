package bussiness.helper;

import presentation.Constants;
import bussiness.action.AbstractActionFactory;
import bussiness.action.ActionIf;
import bussiness.initialiser.AbstractInitialiserFactory;
import bussiness.initialiser.InitialiserIf;
import bussiness.processor.AbstractProcessorFactory;
import bussiness.processor.ProcessorIf;
import bussiness.validator.AbstractValidatorFactory;
import bussiness.validator.ValidatorIf;
import integretion.model.FactoryInfo;
import service.StateMgr;
import service.to.AbstractTOFactory;
import service.to.BaseTO;

public class ObjGeneratorHelper {

	/**
     * Gets the Transfer Object from the TOFactory.
     */
	public static BaseTO getTransferObj(StateMgr stateMgr, String toID){

		AbstractTOFactory tofactory = stateMgr.getTOFactory();
		if(tofactory==null){
			System.out.println("error when get TOFactory");
			return null;
		}
		
		BaseTO to = null;
		
		/*
		 * 	TOMap was init when App context was read,
		 * 	if TOMap is null,that is bug.
		 */
		String toName = stateMgr.getBeanMap().get(toID);
		
		if(toName!=null && toName.length()>0){
			// get factory info which type == "bean"
			FactoryInfo info = stateMgr.getFactoryInfo(Constants.FACTORY_TYPE_TO);
			boolean isCached = info.isCached();
			to = tofactory.create(toName, isCached);
		}

		if(to==null)
			to = new BaseTO();
		
		to.setCurrentActionID(toID);
		
		return to;
	}
	
	 /**
     * Gets the ActionIf object from the ActionFactory.
     */
	
	public static ActionIf getActionIf(StateMgr stateMgr, String actionID){
		AbstractActionFactory actionFactory = stateMgr.getActionFactory();
		
		if(actionFactory==null){
			System.out.println("actionFactory should not be null!");
			return null;
		}
		
		String actionName = stateMgr.getActionMap().get(actionID);
		ActionIf action = null;
		
		FactoryInfo info = stateMgr.getFactoryInfo(Constants.FACTORY_TYPE_ACTION);
		boolean isCached = info.isCached();
		
		action = actionFactory.create(actionName, isCached);
		
		if(action==null){
			System.out.println("can't create action instance");
		}
		
		action.setID(actionID);
			
		return action;
	}
	
	
	/**
     * Gets the ProcessorIf object from the ProcessorFactory.
     */
	public static ProcessorIf getProcessorIf(StateMgr stateMgr, String processorID){
		AbstractProcessorFactory processorFactory = stateMgr.getProcessorFactory();
		
		if(processorFactory==null){
			System.out.println("processorFactory should not be null!");
			return null;
		}
		
		String processorName = stateMgr.getProcessorMap().get(processorID);
		ProcessorIf processor = null;
		FactoryInfo info = stateMgr.getFactoryInfo(Constants.FACTORY_TYPE_PROCESSOR);
		boolean isCached = info.isCached();
		processor = processorFactory.create(processorName, isCached);
		
		if(processor==null){
			System.out.println("can't create processor instance");
		}
		
		processor.setID(processorID);
		return processor;
		
	}
	
	
	public static InitialiserIf getInitialiserIf(StateMgr stateMgr, String initialiserID){
		AbstractInitialiserFactory initialiserfactory = stateMgr.getInitialiserFactory();
		if(initialiserfactory==null){
			System.out.println("initialiserFactory should not be null!");
			return null;
		}
		
		String initialiserName = stateMgr.getInitialiserMap().get(initialiserID);
		InitialiserIf initialiser = null;
		FactoryInfo info = stateMgr.getFactoryInfo(Constants.FACTORY_TYPE_INITIALISER);
		boolean isCached = info.isCached();
		
		initialiser = initialiserfactory.create(initialiserName, isCached);
		
		if(initialiser==null){
			System.out.println("can't create initialiser instance");
		}
		
		initialiser.setID(initialiserID);
		
		return initialiser;
		
	}
	
	public static ValidatorIf getValidatorIf(StateMgr stateMgr, String validatorID){
		AbstractValidatorFactory validatorFactory = stateMgr.getValidatorFactory();
		if(validatorFactory==null){
			System.out.println("validatorFactory should not be null!");
			return null;
		}
		
		String validatorName = stateMgr.getValidatorMap().get(validatorID);
		ValidatorIf validator = null;
		FactoryInfo info = stateMgr.getFactoryInfo(Constants.FACTORY_TYPE_VALIDATOR);

		boolean isCached = info.isCached();
		
		validator = validatorFactory.create(validatorName, isCached);
		
		if(validator==null){
			System.out.println("can't create validator instance");
		}
		validator.setID(validatorID);
		return validator;
	}
	
}
