package bussiness.initialiser;

public abstract class AbstractDynaInitialiserFactory extends AbstractInitialiserFactory{

	 protected InitialiserIf create(String initialiserName){
		InitialiserIf result = null;
		 
		if(initialiserName==null){
			System.out.println("initialiserName should not be null while create InitialiserIf!");
			return null;
		}
		try{
			result = (InitialiserIf)Class.forName(initialiserName).newInstance();
		}
		 catch(Exception e){
			 
		 }
		 return result;
	 }
}
