package bussiness.dispatcher;

import bussiness.action.ActionIf;
import service.StateMgr;

/**
 	A Forward Dispatcher will:  
 		PROCESS the current screen, GET the next screen, 
 		and check if it is to be skipped. If yes, continue 
 		to get the next screen until found the page not to 
 		be skipped, INITIALISE the next screen
 *
 */

public class ForwardDispatcher extends AbstractBaseDispatcher{

	@Override
	protected String dispatch(StateMgr stateMgr) {
		
		String destActionID = "";
		
		//----- PROCESS Current Screen, then INITIALISE Next Screen
		processCurrentScreen(stateMgr);
		
		destActionID = initialiseNextScreen(stateMgr);
		
		stateMgr.getFlowCtrl().setCurrentMainID(destActionID);
		 
		String viewID = stateMgr.getViewMap().get(destActionID);
		
		return viewID;
	}
	
	
	private String processCurrentScreen(StateMgr stateMgr){
		String currentID = stateMgr.getFlowCtrl().getCurrentMainID();
		
		ActionIf action = getActionIf(stateMgr,currentID);
		action.process(stateMgr);
		
		return currentID;
	}
	
	private String initialiseNextScreen(StateMgr stateMgr){
		FlowCtrlIf flowCtrl = stateMgr.getFlowCtrl();
		String nextID = flowCtrl.getCurrentMainID();
		ActionIf action = null;
		boolean needSkipThisAction = true;
		while(needSkipThisAction){
			nextID = flowCtrl.getNextID(nextID, stateMgr);
			action = getActionIf(stateMgr,nextID);
			needSkipThisAction = action.isSkipOnForward(stateMgr);
		}
		
		action.initialise(stateMgr);
		
		return nextID;
	}

}
