package bussiness.model;

public interface ProductIf {

	void setProductName(String name);
	String getProductName();
	
	void setProductPrice(double price);
	double getProductPrice();
	
	String getUsage();
	void setUsage(String s);
}
