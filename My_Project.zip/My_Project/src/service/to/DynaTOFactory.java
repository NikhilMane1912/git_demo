package service.to;

public class DynaTOFactory extends AbstractDynaTOFactory{

}
