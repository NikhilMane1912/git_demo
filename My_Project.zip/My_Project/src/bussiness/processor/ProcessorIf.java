package bussiness.processor;

import service.StateMgr;

/**
 * 	Processors are accessed and controlled via Actions, 
 * 	and are the most crucial business components, acting as 
 * 	the main business controller for a specific screen or product. 
 * 
 */



public interface ProcessorIf {
	
	/**
    * Set the current action ID.
    */
    void setID(String theID);
    
    /**
     * Return the current Action ID.
     */
    String getID();

    
    /**
     * Initialise the process event.
     */
    void initialise(StateMgr mgr);
    
    
    /**
     * Process the default event  for current request.
    */
    void process(StateMgr mgr);
    
    
    /**
     * Process alternate event that may be triggered by the request.
     */
    void processOther(StateMgr mgr, String processOtherID);
    
    
    /**
     * Retrieve the response from the process event.
     */
    void retrieve(StateMgr mgr) ;
    
    
    /**
     * Validates the transfer object. This is meant for complete validation.
     */
    void validate(StateMgr mgr);

    
}
