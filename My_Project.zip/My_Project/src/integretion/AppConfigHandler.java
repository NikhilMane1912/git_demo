package integretion;

import java.util.Stack;

import integretion.model.DataSourceInfo;
import integretion.model.FactoryInfo;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import service.AppContext;

public class AppConfigHandler extends DefaultHandler{

	private AppContext appContext = null;
	
	private String tag = null;//当前解析的元素标签
	
	// Stack 用于元素嵌套问题
	// tag用于记下当前是什么元素
	private Stack stack = new Stack();
	
	AppConfigHandler(AppContext context){
		this.appContext = context;
	}
	
	/**
     *      接收文档的开始的通知。
     */
	@Override
	public void startDocument() throws SAXException {
		
	}
	
	
	 /**
     *     接收元素开始的通知。
     *  namespaceURI:元素的命名空间
     *  localName:元素的本地名称（不带前缀）
     *  qName:元素的限定名（带前缀）
     *  atts:元素的属性集合
     *  
     *  注意：
     *  	由于有些环境不一样，有时候第二个参数有可能为空，
     *  	所以可以使用第三个参数
     */
	@Override
	public void startElement(String uri, String qName, String localName, Attributes attributes) 
			throws SAXException {
		if(localName.equals("config")){
			String id = attributes.getValue("id");
			String value = attributes.getValue("value");
			this.appContext.stroeToConfigMap(id, value);
		}
		else if(localName.equals("datasource")){
			String id = attributes.getValue("id");
			String name = attributes.getValue("name");
			String type = attributes.getValue("type");
			DataSourceInfo info = new DataSourceInfo(); 
			info.setId(id);
			info.setName(name);
			info.setType(type);
			stack.push(info);
			tag = "datasource";
		}
		else if(localName.equals("dsparam")){
			if(tag.equals("datasource")){
				DataSourceInfo info = (DataSourceInfo)stack.peek();
				String name = attributes.getValue("name");
				String value = attributes.getValue("value");
				info.setToParamMap(name, value);
			}
		}
		else if(localName.equals("factory")){
			String type = attributes.getValue("type");
			String className = attributes.getValue("className");
			String cache = attributes.getValue("cache");
			FactoryInfo info = 
				new FactoryInfo(className,type,Boolean.valueOf(cache));
			
			this.appContext.storeToFactoryMap(info);
			
		}
	}
	
	
	 /**
     *      接收字符数据的通知。
     *      
     *      注意：
     *      	空白在Sax解析器中，被认为是TextNode(尽管不是我们想要的数据)
     */
	/*
	@Override
	public void characters(char[] ch, int start, int length) 
			throws SAXException {
		if("".equals("config")){
			
		}
	}*/
	
	 /**
     *      接收文档的结尾的通知。
     *     uri:元素的命名空间
     *     localName:元素的本地名称（不带前缀）
     *     name:元素的限定名（带前缀）
     */
	@Override
	public void endElement(String uri, String qName, String localName)
			throws SAXException {
		if(localName.equals("config")){
			
		}
		else if(localName.equals("datasource")){
			DataSourceInfo info = (DataSourceInfo)stack.pop();
			this.appContext.stroeToDataSourceInfoMap(
					info.getId(), info);
			tag = null;
		}
	}
}
