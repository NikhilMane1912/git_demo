package bussiness.processor;

import bussiness.model.UserProfileModel;
import service.StateMgr;
import service.to.BaseTO;
import service.to.UserProfileTO;

public class UserProfileProcessor extends BaseProcessor{

	
	
	@Override
	protected void populateBeanFromModel(StateMgr mgr) {
		UserProfileTO to = null;
		to = (UserProfileTO) createBean(mgr);
		UserProfileModel model = mgr.getBusinessContext().getUserProfile();
		
		to.setName(model.getName());
		to.setGender(model.getGender());
	//	to.setUserID(model.getUserID());
		if(model.isInfoNeedSupplement())
			to.setInfoNeedSupplement("Yes");
		else
			to.setInfoNeedSupplement("No");
		
		mgr.getBusinessContext().setBaseTO(to);
	}

	@Override
	protected void populateModelFromBean(StateMgr mgr) {
		/*
		 *  here, transferobject should be not null 
		 *  and type is UserProfileTO 
		 */
		UserProfileTO to = (UserProfileTO)mgr.getBusinessContext().getBaseTO();

		UserProfileModel model = mgr.getBusinessContext().getUserProfile();
		model.setName(to.getName());
		model.setPassword(to.getPassword());
		
		if(to.isInfoNeedSupplement().equals("Yes")){
			model.setInfoNeedSupplement(true);
		}
		else
			model.setInfoNeedSupplement(false);

		
	}

}
