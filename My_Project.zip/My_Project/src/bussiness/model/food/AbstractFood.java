package bussiness.model.food;

import bussiness.model.ProductIf;

public abstract class AbstractFood implements ProductIf{

	private String productName = null;
	private double productPrice = 0;

	public AbstractFood(String name,double price){
		this.setProductName(name);
		this.setProductPrice(price);
	}

	public void setProductName(String name) {
		this.productName = name;
	}
	public String getProductName() {
		return this.productName;		
	}
	

	public void setProductPrice(double price) {
		this.productPrice = price;
	}
	public double getProductPrice() {
		return this.productPrice;
	}

	
}
