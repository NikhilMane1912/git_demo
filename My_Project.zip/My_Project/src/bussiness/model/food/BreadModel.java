package bussiness.model.food;

public class BreadModel extends AbstractFood{

	private String uasge = null;
	
	public BreadModel(String name,double price){
		super(name,price);
	}
	
	public String usage() {
		return "just eat it";
	}
	
	public String toString(){
		return this.getProductName()+" Price is:"+
			this.getProductPrice()+"Usage is:"+usage();
	}

	@Override
	public String getUsage() {
		return uasge;
	}

	@Override
	public void setUsage(String ausage) {
		this.uasge = ausage;
	}


}
