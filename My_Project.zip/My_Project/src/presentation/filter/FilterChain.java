package presentation.filter;

import java.util.ArrayList;

public class FilterChain {

	private ArrayList<AbstractFilter> filterList = null;
	
	FilterChain(){
		this.filterList = new ArrayList<AbstractFilter>();
	}
	
	public void addFilter(AbstractFilter filter){
		filterList.add(filter);
	}
	
	public void clearFilters(){
		filterList.clear();
	}
	
	public String processFilters(FilterContext filterContext){
		AbstractFilter filter = null;
		String result = null;
		for(int i=0;i<filterList.size() && result==null ;i++){
			filter = filterList.get(i);
			result = filter.process(filterContext);
		}
		return result;
	}
	
}
