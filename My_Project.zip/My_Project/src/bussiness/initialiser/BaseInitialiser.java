package bussiness.initialiser;

import service.StateMgr;

public abstract class BaseInitialiser extends AbstractBaseInitialiser {

	public abstract void initialise(StateMgr mgr);
	
	public void initialiseOther(StateMgr mgr, String initialiseOtherID){
		
	}
}
