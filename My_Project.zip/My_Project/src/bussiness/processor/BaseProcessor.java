package bussiness.processor;

import bussiness.helper.ObjGeneratorHelper;
import bussiness.initialiser.InitialiserIf;
import bussiness.validator.ValidatorIf;
import service.StateMgr;
import service.to.BaseTO;

public abstract class BaseProcessor extends AbstractBaseProcessor{

	@Override
	public void initialise(StateMgr mgr) {
		InitialiserIf initialiser = getInitialiser(mgr,getID());
		initialiser.initialise(mgr);
		
	}
	
	
	protected InitialiserIf getInitialiser(StateMgr mgr, String initialiserId){
		InitialiserIf result = null;
		
		result = ObjGeneratorHelper.getInitialiserIf(mgr, initialiserId);
		
		return result;
	}
	
	protected ValidatorIf getValidator(StateMgr mgr, String validatorID){
		ValidatorIf validator = null;
		validator = ObjGeneratorHelper.getValidatorIf(mgr, validatorID);
		return validator;
	}
	

	@Override
	public void process(StateMgr stateMgr) {
		
		populateModelFromBean(stateMgr);
	}

	@Override
	public void processOther(StateMgr mgr, String processOtherID) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void retrieve(StateMgr mgr) {
		
		populateBeanFromModel(mgr);
	}

	@Override
	public void validate(StateMgr mgr) {
		ValidatorIf validator = getValidator(mgr,getID());
		validator.validate(mgr);
	}
	
	
	/**
     * Creates a TransferObject using the TOFactory mechanism.
     */
	protected BaseTO createBean(StateMgr mgr){
		return ObjGeneratorHelper.getTransferObj(mgr, getID());
	}
	
	
	
	
	
	 /**
     * Populate the model to transfer object bean.
     */
	protected abstract void populateBeanFromModel(StateMgr mgr);
	
	
	 /**
     * Populate the transfer object bean to model.
     */
	 protected abstract void populateModelFromBean(StateMgr mgr);
	

}
