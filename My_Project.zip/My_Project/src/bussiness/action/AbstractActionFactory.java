package bussiness.action;

import java.util.HashMap;

public abstract class AbstractActionFactory {

	private HashMap<String,ActionIf> ActionIfMap = new HashMap<String,ActionIf>();
	
	public ActionIf create(String actionName, boolean isCached){
		ActionIf action = null;
		
		if(isCached){
			if(ActionIfMap.containsKey(actionName)){
				return ActionIfMap.get(actionName);
			}
			else{
				synchronized(ActionIfMap){
					if(ActionIfMap.containsKey(actionName)){
						return ActionIfMap.get(actionName);
					}
					action = create(actionName);
					if(action==null){
						System.out.println("create action fail!");
					}
					ActionIfMap.put(actionName, action);
				}
			}
			
		}
		else{
			action = create(actionName);
		}
		return action;
	}
	
	
	protected abstract ActionIf create(String actionName);
		
}
