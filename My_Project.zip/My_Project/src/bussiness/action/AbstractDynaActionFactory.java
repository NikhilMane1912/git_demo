package bussiness.action;

public abstract class AbstractDynaActionFactory extends AbstractActionFactory{

	protected ActionIf create(String actionName){
		ActionIf result = null;
		
		if(actionName==null){
			System.out.println("actionName should not be null while create ActionIf!");
			return null;
		}
		
		try{
			result = (ActionIf) Class.forName(actionName).newInstance();
		}catch(Exception e){
			
		}
		
		return result;
	}
}
