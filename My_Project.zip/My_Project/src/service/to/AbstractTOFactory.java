package service.to;

import java.util.HashMap;
import java.util.Map;

public abstract class AbstractTOFactory {

	private Map repository = new HashMap();
	
	public BaseTO create(String toName, boolean isCached){
		BaseTO baseTO = null;
		
		if (isCached) {
			Object o = repository.get(toName);
			if(o!=null)
				baseTO = (BaseTO) o;
		}
		
		if(baseTO==null){
			baseTO = create(toName);
			repository.put(toName, baseTO);
		}
		
		return baseTO;
	}
	
	public abstract BaseTO create(String toName);

	
}
