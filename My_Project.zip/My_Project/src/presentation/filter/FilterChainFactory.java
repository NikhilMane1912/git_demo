package presentation.filter;

import java.util.HashMap;

import presentation.filter.postRequest.TransferObjPostFilter;
import presentation.filter.postRequest.ViewDispatchPostFilter;
import presentation.filter.preRequest.*;

/*
 *  use to create FilterChain.
 *  according to different parameter,create different FilterChain
 */

public class FilterChainFactory {

	private HashMap<Integer,FilterChain> cacheFilterChain = new HashMap<Integer,FilterChain>();
	
	public FilterChain get(int filterChainType){
		FilterChain chain = null;
		
		//first look up at cache
		if(cacheFilterChain.containsKey(filterChainType)){
			chain = cacheFilterChain.get(filterChainType);
		}
		else{
			// need to creat a chain
			chain = create(filterChainType);
			
		}
		return chain;
	}
	
	
	//create and initial the chain
	public FilterChain create(int filterChainType){
		
		switch(filterChainType){
		
		case FilterConstants.PRE_REQUEST :
			return createPreRequestFilterChain();
			
		case FilterConstants.POST_REQUEST :
			return createPostRequestFilterChain();
			
		default :
			return null;
		}
		
	}
	
	public FilterChain createPreRequestFilterChain(){
		FilterChain chain = new FilterChain();
		
		//add StateMgrPreFilter first !
		chain.addFilter(new StateMgrPreFilter());
		
		chain.addFilter(new TransferObjPreFilter());
		
		chain.addFilter(new DBConnectionsPreFilter());
		return chain;
	}
	
	public FilterChain createPostRequestFilterChain(){
		FilterChain chain = new FilterChain();
		
		chain.addFilter(new TransferObjPostFilter());
		chain.addFilter(new ViewDispatchPostFilter());

		return chain;
	}
}
