package service.to;

public class AbstractProductTO extends BaseTO{

	private String productName = null;
	private double productPrice = 0;
	
	public void setProductName(String name) {
		this.productName = name;
	}
	public String getProductName() {
		return this.productName;		
	}
	

	public void setProductPrice(double price) {
		this.productPrice = price;
	}
	public double getProductPrice() {
		return this.productPrice;
	}
}
