package bussiness.action;

import service.StateMgr;

public class SupplementActionCtrl extends BaseActionCtrl{

	public boolean isSkipOnForward(StateMgr stateMgr){
		boolean needSkip = stateMgr.getBusinessContext().
				getUserProfile().isInfoNeedSupplement();
		
		return !needSkip;
	}
	
	public boolean isSkipOnBackward(StateMgr stateMgr){
		boolean needSkip = stateMgr.getBusinessContext().
				getUserProfile().isInfoNeedSupplement();
		
		return !needSkip;
	}
}
