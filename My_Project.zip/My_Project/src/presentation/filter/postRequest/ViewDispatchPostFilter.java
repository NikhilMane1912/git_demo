package presentation.filter.postRequest;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import presentation.filter.AbstractFilter;
import presentation.filter.FilterContext;

public class ViewDispatchPostFilter extends AbstractFilter{

	@Override
	public String process(FilterContext filterContext) {

		forward(filterContext);

		return null;
	}
	
	
	protected void forward(FilterContext filterContext){
		 HttpServletRequest request = filterContext.getRequest();
	     HttpServletResponse response = filterContext.getResponse();
	     
	     String view = filterContext.getView();
	     RequestDispatcher requestDispatcher = 
	    		 filterContext.getServletContext().getRequestDispatcher(view);
	     
	     try{
	    	 requestDispatcher.forward(request, response);
	     }catch(Exception e){
	    	 
	     }
	}

}
