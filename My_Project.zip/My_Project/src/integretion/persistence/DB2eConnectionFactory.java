package integretion.persistence;

import integretion.model.DataSourceInfo;

public class DB2eConnectionFactory extends DBConnectionFactory{


}
