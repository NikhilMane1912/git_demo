package service.to;

public class BaseTO {
	
	protected static final String BLANK = "";
	
	private String currentActionID = BLANK;
	private String direction = BLANK;
	private String processOtherID = BLANK;
	private String targetActionID = BLANK;
	
	private boolean openNewWindow = false;
	
	public String getCurrentActionID() {
		return currentActionID;
	}
	public void setCurrentActionID(String currentActionID) {
		this.currentActionID = currentActionID;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getProcessOtherID() {
		return processOtherID;
	}
	public void setProcessOtherID(String processOtherID) {
		this.processOtherID = processOtherID;
	}
	public String getTargetActionID() {
		return targetActionID;
	}
	public void setTargetActionID(String targetActionID) {
		this.targetActionID = targetActionID;
	}
	public boolean isOpenNewWindow() {
		return openNewWindow;
	}
	public void setOpenNewWindow(boolean openNewWindow) {
		this.openNewWindow = openNewWindow;
	}
	
	
	
}
