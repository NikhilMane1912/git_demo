package bussiness.action;

import service.StateMgr;
import service.to.BaseTO;

public class PdtDetailActionCtrl extends BaseActionCtrl{

	public void processOther( StateMgr mgr, String operationToPerform ){
		super.processOther(mgr, operationToPerform);
		
		if(operationToPerform.equals("print")){
			openReportGenerationWindow(mgr);
		}
		
		
	}
	
	
	private void openReportGenerationWindow( StateMgr stateMgr ){
		BaseTO to = stateMgr.getTransferObject();
		
		to.setOpenNewWindow(true);
		to.setDirection("NewWindow");
		to.setTargetActionID("RPTGENPDF");
	}
}
