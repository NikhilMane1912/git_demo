package bussiness.validator;

import service.StateMgr;

public abstract class AbstractBaseValidator implements ValidatorIf{

	private String ID = null;
	public void setID(String theID) {
		this.ID = theID;
	}
	public String getID(){
		return this.ID;
	}
	
	
	public abstract void validate(StateMgr mgr);
	
	public abstract void validateOther(StateMgr mgr, String validatorOtherID);
}
