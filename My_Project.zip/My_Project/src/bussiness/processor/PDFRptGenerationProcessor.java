package bussiness.processor;

import bussiness.model.ReportModel;
import service.StateMgr;
import service.to.ReportTO;

public class PDFRptGenerationProcessor extends BaseProcessor {

	@Override
	public void initialise(StateMgr mgr){
	/*
	 * Trigger the illustration process & aggregation process.
	 */
		
		
		
		String pdfPath = "C:\\workspace\\My_Project\\WebContent\\PDF\\jvm.pdf";
	}
	
	@Override
	protected void populateBeanFromModel(StateMgr mgr) {
		ReportTO bean = null;
		ReportModel rptModel = mgr.getBusinessContext().getRptModel();
		bean = (ReportTO) createBean(mgr);
		
		//bean.setTargetURL(rptModel.getReportURL());
		bean.setTargetURL("http://localhost:8080/My_Project/PDF/jvm.pdf");
		mgr.setTransferObject(bean);

	}

	@Override
	protected void populateModelFromBean(StateMgr mgr) {
		// TODO Auto-generated method stub
		
	}

}
