package service;

import integretion.model.FactoryInfo;
import integretion.persistence.DBConnectionFactory;
import integretion.persistence.DBConnectionMgr;

import java.util.HashMap;

import bussiness.action.AbstractActionFactory;
import bussiness.dispatcher.AbstractBaseDispatcher;
import bussiness.dispatcher.FlowCtrlIf;
import bussiness.initialiser.AbstractInitialiserFactory;
import bussiness.processor.AbstractProcessorFactory;
import bussiness.validator.AbstractValidatorFactory;

import service.to.AbstractTOFactory;
import service.to.BaseTO;

/*
 * This class will act as a facade for the underlying data/state 
 * through out the application life cycle. Serve as one single point 
 * of entry from other layers to access the information that shared 
 * among layers.
 */

public class StateMgr {

	private AppContext applicationContext = null;
	private BusinessContext businessContext = null;
    private SessionContext sessionContext = null;
    
	public AppContext getApplicationContext() {
		return applicationContext;
	}
	public void setApplicationContext(AppContext applicationContext) {
		this.applicationContext = applicationContext;
	}
	public BusinessContext getBusinessContext() {
		return businessContext;
	}
	public void setBusinessContext(BusinessContext businessContext) {
		this.businessContext = businessContext;
	}
	public SessionContext getSessionContext() {
		return sessionContext;
	}
	public void setSessionContext(SessionContext sessionContext) {
		this.sessionContext = sessionContext;
	}
    
	
	public BaseTO getTransferObject(){
		BusinessContext context = this.getBusinessContext();
		if(context==null)
			return null;
		else
			return context.getBaseTO();
	}
	
	public void setTransferObject(BaseTO to){
		BusinessContext context = this.getBusinessContext();
		if(context==null)
			return;
		else
			context.setBaseTO(to);
	}
	
	
	public AbstractTOFactory getTOFactory(){
		return getApplicationContext().getTOFactory();
	}
    
	public HashMap<String,String> getTOMap(){
		return getApplicationContext().getTOMap();
	}
	
	/*
	 *  factoryMap is <id,FactoryInfo> struct
	 */
	public FactoryInfo getFactoryInfo(String factoryType){
		HashMap<String,FactoryInfo> map = getApplicationContext().getFactoryMap();
		
		//map should not be null
		FactoryInfo info = map.get(factoryType);
		return info;
	}
    
	
	// Dispatch
	public AbstractBaseDispatcher getDispatcher(String dispatcherName){
		HashMap<String,AbstractBaseDispatcher> map = getApplicationContext().getDispatcherMap();
		Object o = map.get(dispatcherName);
		if(o!=null)
			return (AbstractBaseDispatcher)o;
		
		return null;
	}
	
	
	/**
     * Return the flow controller
     */
	public FlowCtrlIf getFlowCtrl(){
		return getSessionContext().getFlowCtrl();
	}
	
	
	/**
	 *  Action Factory
	 */
    public AbstractActionFactory getActionFactory(){
    	return getApplicationContext().getActionFactory();
    }
    
    
    /**
     *  Processor Factory
     */
    public AbstractProcessorFactory getProcessorFactory(){
    	return getApplicationContext().getProcessorFactory();
    }
    
    /**
     *  Initialiser Factory
     */	
    public AbstractInitialiserFactory getInitialiserFactory(){
    	return getApplicationContext().getInitialiserFactory();
    }
    
    /**
     *  Validator Factory
     */	
    public AbstractValidatorFactory getValidatorFactory(){
    	return getApplicationContext().getValidatorFactory();
    }
    
    /**
     *  DB Connection Factory
     */
    public DBConnectionFactory getDBConnectionFactory(){
    	return getApplicationContext().getDBConnectionFactory();
    }
    
    /**
     	DB connection mgr
     */
    public DBConnectionMgr getDBConnectionMgr() {
    	return getSessionContext().getConnectionMgr();
    }
    
    
    /*
     *  get map info read from bizCofig
     */
    public HashMap<String,String> getViewMap(){
    	return getApplicationContext().getViewMap();
    }
    public HashMap<String,String> getBeanMap(){
    	return getApplicationContext().getBeanMap();
    }
    public HashMap<String,String> getActionMap(){
    	return getApplicationContext().getActionMap();
    }
    public HashMap<String,String> getInitialiserMap(){
    	return getApplicationContext().getInitialiserMap();
    }
    public HashMap<String,String> getValidatorMap(){
    	return getApplicationContext().getValidatorMap();
    }
    public HashMap<String,String> getProcessorMap(){
    	return getApplicationContext().getProcessorMap();
    }
}
