package presentation.helper;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Map;

import bussiness.helper.ObjGeneratorHelper;

import presentation.Constants;

import service.StateMgr;
import service.to.BaseTO;

/*
 * 	Mapping HTTP request parameters to appropriate Transfer Objects
 */

public class TransferObjectHelper {
	
	public static void MergeParameterIntoTransferObject(StateMgr stateMgr, Map parameters){
		
		if(stateMgr==null || parameters==null)
			return;
		
		
		
		// get Transfer Object from StateMgr
		BaseTO to = getTransferObject(stateMgr,parameters);
		
		// here BaseTO to must not be null
		
		
		ArrayList setterMethods = new ArrayList();
		ArrayList propertyList = new ArrayList();
		getPropertyAndMethodList(to,setterMethods,propertyList);
		
		for(int i=0;i<propertyList.size();i++){
			String name = (String)propertyList.get(i);
			
			//need to call the setter
			String subString1 = name.substring(0, 1);
			String subString2 = name.substring(1);
			String lowerCaseName = subString1.toLowerCase().concat(subString2);
			String upperCaseName = subString1.toUpperCase().concat(subString2);
			
			if(!setBeanProperty(to,parameters,(Method)setterMethods.get(i),lowerCaseName))
				setBeanProperty(to,parameters,(Method)setterMethods.get(i),upperCaseName);
		}
		
		
		stateMgr.setTransferObject(to);
	}
	
	private static boolean setBeanProperty(Object bean,Map properties,Method setterMethod, String propertyName){
		boolean flag = false;
	
		Object o = properties.get(propertyName);
		if(o!=null){
			Class[] paramTypes = setterMethod.getParameterTypes();
			
			// paramTypes is the value need to be set into bean
			//should not be null
			Object[] param =(Object[])o;
			
		/*
		* assumes the Bean's setter has one parameter
		* and setter is public 
		*/
		try {
			// Non-Array value
			/*
			 *  need to check para type because:
			 *  	setA(int A) and setA(String b)
			 */
			if(param.length==1){
				if(paramTypes[0].equals(param[0].getClass())){
					setterMethod.invoke(bean, param);
					flag = true;
				}
			}
			else{	//the parameter which will be set into bean is Array value
				//but it seems this will not happen here
				if(paramTypes[0].equals(param.getClass())){
					//
				}
			}
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
			
		}
				
		
		return flag;
	}
	
	
	private static BaseTO getTransferObject(StateMgr stateMgr, Map parameters){
		BaseTO to = stateMgr.getTransferObject();
		
		if(to!=null)
			return to;
		
		String currentActionID = (String) parameters.get(Constants.REQUEST_CURRENT_ACTION_ID);
		to = ObjGeneratorHelper.getTransferObj(stateMgr, currentActionID);
		return to;
	}
	
	/**
     * 	Gets a list of property name and the corresponding getter and setter.
     *
     * 	@param bean Object
     * 	@param getterMethods ArrayList to contain setter Method objects.
     * 	@param setterMethods ArrayList to contain getter Method objects.
     * 	@param propertyList  ArrayList to contain String of property names.
     */
	private static void getPropertyAndMethodList(Object bean,
			ArrayList setterMethods,ArrayList propertyList){
		Method[] methodList = bean.getClass().getMethods();
		if(methodList==null)
			return;
		
		String methodName = null;
		String possiblePropertyName = null;
		/*
		 * 	we just focus on setXX
		 */
		for(int i=0;i<methodList.length;i++){
			methodName = methodList[i].getName();
			if(methodName.startsWith("set")){
				possiblePropertyName = methodName.substring(3);
			}
			
			if(possiblePropertyName!=null){
				setterMethods.add(methodList[i]);
				propertyList.add(possiblePropertyName);
				possiblePropertyName = null;
			}
		}
		
	}
	
}
