package presentation.filter;

public class FilterConstants {

	public static final int PRE_REQUEST = 1;
    public static final int POST_REQUEST = 2;
}
