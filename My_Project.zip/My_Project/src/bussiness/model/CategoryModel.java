package bussiness.model;

import java.util.ArrayList;

/*
 * 	contain category info
 */

public class CategoryModel {

	private ArrayList<String> ProductTypes;
	
	private String selectedType = null;
	
	public CategoryModel(){
		
		this.ProductTypes = new ArrayList<String>();
	}

	public String getSelectedType() {
		return selectedType;
	}
	public void setSelectedType(String selectedType) {
		this.selectedType = selectedType;
	}

	public ArrayList<String> getProductTypes(){
		return ProductTypes;
	}
	
	public void setProductTypes(ArrayList<String> productTypes){
		this.ProductTypes = productTypes;
	}
	
	public void addProductType(String type){
		this.ProductTypes.add(type);
	}
	
}
