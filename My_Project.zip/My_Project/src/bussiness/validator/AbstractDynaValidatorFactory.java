package bussiness.validator;

public abstract class AbstractDynaValidatorFactory extends AbstractValidatorFactory{

	 protected ValidatorIf create(String validatorName){
		 ValidatorIf result = null;
		 
		 try {
			result = (ValidatorIf) Class.forName(validatorName).newInstance();
		} 
		 catch (Exception e) {
			e.printStackTrace();
		}
		 
		 return result;
	 }
}
