package service;

import integretion.persistence.DBConnectionMgr;
import bussiness.dispatcher.FlowCtrlIf;

public class SessionContext {

	private FlowCtrlIf flowCtrl = null;
	public void setFlowCtrl(FlowCtrlIf aFlowCtrl) {
        this.flowCtrl = aFlowCtrl;
    }
	public FlowCtrlIf getFlowCtrl() {
        return this.flowCtrl;
    }
	
	
	
	private DBConnectionMgr connectionMgr = null;
	public DBConnectionMgr getConnectionMgr() {
		return connectionMgr;
	}
	public void setConnectionMgr(DBConnectionMgr connectionMgr) {
		this.connectionMgr = connectionMgr;
	}
	 
}
