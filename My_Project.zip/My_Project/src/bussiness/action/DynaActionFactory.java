package bussiness.action;

public class DynaActionFactory extends AbstractDynaActionFactory{

}
