package service.to;

public abstract class AbstractDynaTOFactory extends AbstractTOFactory{

	public BaseTO create(String toName){
		BaseTO result = null;
		
		if(toName == null){
			System.out.println("error at create BaseTO");
			return null;
		}
		
		try {
			result = (BaseTO)Class.forName(toName).newInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
		
	}

}
