package bussiness.validator;

import service.StateMgr;

public class CategoryValidator extends BaseValidator{

	@Override
	public void validate(StateMgr mgr) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void validateOther(StateMgr mgr, String validatorOtherID) {
		// TODO Auto-generated method stub
		
	}

}
