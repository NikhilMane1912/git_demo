package integretion.persistence;

import java.sql.Connection;

public class DB2eAccessor extends DBAccessor{

	public DB2eAccessor(Connection theConnection) {
		super(theConnection);
	}

}
