package bussiness.initialiser;

import java.util.ArrayList;

import bussiness.model.ProductListModel;
import bussiness.model.ProductIf;
import bussiness.model.food.*;
import service.BusinessContext;
import service.StateMgr;

public class FoodListInitialiser extends BaseInitialiser{

	@Override
	public void initialise(StateMgr mgr) {
		BusinessContext context = mgr.getBusinessContext();
		ProductListModel productDetailsModel = 
				context.getProductListModel();
		if(productDetailsModel==null){
			productDetailsModel = new ProductListModel();
			initProductDetailsModel(productDetailsModel);
		}
		
		context.setProductListModel(productDetailsModel);
	}
	
	public void initProductDetailsModel(ProductListModel model){
		ArrayList<String> foodDetails = new ArrayList<String>();
		foodDetails.add("Bread");
		foodDetails.add("Fish");
		model.setList(foodDetails);
	}

}
