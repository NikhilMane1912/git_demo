package bussiness.action;

import bussiness.processor.ProcessorIf;
import service.StateMgr;

public class BaseActionCtrl extends AbstractBaseActionCtrl{

	
	/**
     * Calls the Processor's initialise() method.
    */
	@Override
	public void initialise(StateMgr stateMgr) {
		ProcessorIf processor = getProcessorIf(stateMgr,getID());
		processor.initialise(stateMgr);
		processor.retrieve(stateMgr);
	}

	@Override
	public void process(StateMgr stateMgr) {
		ProcessorIf processor = getProcessorIf(stateMgr,getID());
		processor.validate(stateMgr);
		processor.process(stateMgr);
		processor.retrieve(stateMgr);
		
	}

	@Override
	public void processOther(StateMgr stateMgr, String operationToPerform) {
		ProcessorIf processor = getProcessorIf(stateMgr,getID());
		processor.processOther(stateMgr, operationToPerform);
		processor.retrieve(stateMgr);
		
	}

	@Override
	public void retrieve(StateMgr stateMgr) {
		ProcessorIf processor = getProcessorIf(stateMgr,getID());
		processor.retrieve(stateMgr);
	}
	

}
