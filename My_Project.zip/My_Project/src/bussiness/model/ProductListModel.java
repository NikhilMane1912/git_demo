package bussiness.model;

import java.util.ArrayList;


public class ProductListModel implements ProductListIF{

	private ArrayList<String> list = null;
	
	private String selectedProduct = null;

	@Override
	public ArrayList<String> getList() {
		return list;
	}

	@Override
	public void setList(ArrayList<String> adetails) {
		this.list = adetails;
	}

	@Override
	public String getSelectedProduct() {
		return selectedProduct;
	}

	@Override
	public void setSelectedProduct(String product) {
		this.selectedProduct = product;
	}


	
	
}
