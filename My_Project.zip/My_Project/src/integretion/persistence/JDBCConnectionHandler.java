package integretion.persistence;

import integretion.model.DataSourceInfo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;

public class JDBCConnectionHandler implements ConnectionHandlerIf{

	private transient Connection conn = null;
	
	
	 //~ Constructors ---
	JDBCConnectionHandler(DataSourceInfo dsInfo){
		prepare(dsInfo);
	}
	
	
	 //~ Methods --------
	
	
	/**
     * Return the active connection instance.
     */
	@Override
	public Connection getConnection() {
		return this.conn;
	}
	
	
	/**
     * Initialise JDBC driver.
     */
	private void initDriver(String driver){
		try{
			Class.forName(driver).newInstance();
		}catch(Exception e){
			
		}
	}
	
	
	/**
     * Setup the connection.
     */
	 protected void setupConnection(String url, String user, String password){
		 try{
			 this.conn = DriverManager.getConnection(url, user, password);
		 }
		 catch(SQLException e){
			 e.printStackTrace();
		 }
	 }
	 
	 
	 
	 /**
	     * Prepare all the JDBC parameters
	 */
	 private void prepare(DataSourceInfo dsInfo){
		 // DsParamMap was set in appconfig.xml
		 HashMap<String, String> params = dsInfo.getDsParamMap();
		 
		  //----- Initialise JDBC driver
		 String driver = (String)params.get("driver");
		 
		 initDriver(driver);
		 
		 String userName = (String)params.get("userid");
		 String password = (String)params.get("password");
		 
		 String url = (String)params.get("url");
		 
		 setupConnection(url,userName,password);
	 }

}
