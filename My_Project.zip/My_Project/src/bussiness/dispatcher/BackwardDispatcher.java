package bussiness.dispatcher;

import bussiness.action.ActionIf;
import service.StateMgr;

public class BackwardDispatcher extends AbstractBaseDispatcher{

	@Override
	protected String dispatch(StateMgr stateMgr) {
		String destActionID = null;
		
		destActionID = retrievePreviousScreen(stateMgr);
		
		stateMgr.getFlowCtrl().setCurrentMainID(destActionID);
		
		String viewID = stateMgr.getViewMap().get(destActionID);
		
		return viewID;
	}

	
	private String retrievePreviousScreen(StateMgr stateMgr){
		FlowCtrlIf flowCtrl = stateMgr.getFlowCtrl();
		String prevID = flowCtrl.getCurrentMainID();
		
		ActionIf action = null;
		boolean needSkipThisAction = true;
		while(needSkipThisAction){
			prevID = flowCtrl.getPreviousID(prevID, stateMgr);
			action = getActionIf(stateMgr,prevID);
			needSkipThisAction = action.isSkipOnBackward(stateMgr);
		}
		action.retrieve(stateMgr);
		return prevID;
	}
}
