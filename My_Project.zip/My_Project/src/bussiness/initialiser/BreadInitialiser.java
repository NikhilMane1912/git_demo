package bussiness.initialiser;

import bussiness.model.ProductIf;
import bussiness.model.food.BreadModel;
import service.BusinessContext;
import service.StateMgr;

public class BreadInitialiser extends BaseInitialiser{

	@Override
	public void initialise(StateMgr mgr) {
		BusinessContext context = mgr.getBusinessContext();
		ProductIf model = context.getSelectedProduct();
		if(model==null){
			model = new BreadModel("CheeseBread",15.6);
			model.setUsage("just eat it!");
		}
		
		context.setSelectedProduct(model);	
	}

}
