package presentation.filter.preRequest;

import integretion.persistence.DBConnectionMgr;
import bussiness.dispatcher.FlowCtrlIf;
import presentation.Constants;
import presentation.filter.AbstractFilter;
import presentation.filter.FilterContext;
import service.AppContext;
import service.BusinessContext;
import service.SessionContext;
import service.StateMgr;

public class StateMgrPreFilter extends AbstractFilter{

	@Override
	public String process(FilterContext filterContext) {
		StateMgr stateMgr = null;
		Object tmpStateMgr = getStateMgr(filterContext);
		
		if(tmpStateMgr==null){
			stateMgr = CreateAndInitStateMgr(filterContext.getAppContext());
		}
		else{
			stateMgr = (StateMgr)tmpStateMgr;
			stateMgr.setApplicationContext(filterContext.getAppContext());
		}
		
		filterContext.storeStateMgr(stateMgr);
		
		return null;
	}
	
	protected StateMgr CreateAndInitStateMgr(AppContext appContext){
		StateMgr stateMgr = new StateMgr();
		stateMgr.setApplicationContext(appContext);
		stateMgr.setSessionContext(initialiseSessionContext(appContext));
		stateMgr.setBusinessContext(initialiseBusinessContext(appContext));
		
		return stateMgr;
	}
	
	
	 protected SessionContext initialiseSessionContext(AppContext appContext){
		 SessionContext context = new SessionContext();
		 context.setFlowCtrl(initFlowControl(appContext));
		 context.setConnectionMgr(initConnectionMgr(appContext));
		 return context;
	 }
	
	 
	 protected BusinessContext initialiseBusinessContext(AppContext appContext){
		 BusinessContext bizCtx = new BusinessContext();
		 
		 return bizCtx;
	 }
	 
	 
	 protected FlowCtrlIf initFlowControl(AppContext appContext){
		 FlowCtrlIf flow = null;
		 String flowControlImplName = appContext.getFromConfigMap(Constants.FLOW_CTRL_Class_NAME);
		 if(flowControlImplName==null){
			 System.out.println("----This is a error!----");
			 
		 }
		 try{
			 flow = (FlowCtrlIf) Class.forName(flowControlImplName).newInstance();
		 }catch(Exception e){
			 System.out.println("----Get Exception when newInstance a FlowCtrlIf----");
		 }
		 
		 return flow;
	 }
	 
	 protected DBConnectionMgr initConnectionMgr(AppContext appContext){
		 DBConnectionMgr mgr = new DBConnectionMgr();
		 return mgr;
	 }
	
	protected Object getStateMgr(FilterContext filterContext){
		Object stateMgr = null;
		if(isStoreStateMgrInSession())
			stateMgr = filterContext.getRequest().getSession().getAttribute(Constants.SESSION_STATE_MGR);
		else
			stateMgr = filterContext.getServletContext().getAttribute(Constants.SESSION_STATE_MGR);
		
		return stateMgr;
	}

}
