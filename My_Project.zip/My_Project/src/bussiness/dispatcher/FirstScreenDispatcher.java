package bussiness.dispatcher;

import bussiness.action.ActionIf;
import service.StateMgr;



public class FirstScreenDispatcher extends AbstractBaseDispatcher{

	
	 /**
     * 	A First Screen Dispatcher will: INITIALISE FlowCtrl and 
     * 	INITIALISE the first screen in the workflow sequence
     */
	@Override
	protected String dispatch(StateMgr stateMgr) {
		 String destActionID = "";
		
		//init FlowCtrl 
		 stateMgr.getFlowCtrl().initialise();

		 //init the 1st Screen in the workflow sequence
		 destActionID = initialiseFirstScreen(stateMgr);
		 
		 stateMgr.getFlowCtrl().setCurrentMainID(destActionID);
		 
		 String viewID = stateMgr.getViewMap().get(destActionID);
		 
		return viewID;
	}
	
	private String initialiseFirstScreen(StateMgr stateMgr){
		FlowCtrlIf flowControl = stateMgr.getFlowCtrl();
		String nextID = flowControl.getFirstID();
		
		// looking for an action to perform
		ActionIf action = null;
		
		action = getActionIf(stateMgr,nextID);
		
		action.initialise(stateMgr);
		
		return nextID;
	}

}
