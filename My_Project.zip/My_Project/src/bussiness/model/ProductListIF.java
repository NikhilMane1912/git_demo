package bussiness.model;

import java.util.ArrayList;

public interface ProductListIF {

	public ArrayList<String> getList();
	public void setList(ArrayList<String> list);
	
	public String getSelectedProduct();
	
	public void setSelectedProduct(String product);
	
}
