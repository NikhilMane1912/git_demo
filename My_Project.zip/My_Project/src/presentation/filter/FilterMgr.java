package presentation.filter;

public class FilterMgr {

	private FilterChainFactory factory = null;
	
	public FilterMgr(FilterChainFactory afactory){
		this.factory = afactory;
	}
	
	public String processFilters(int filterKey, FilterContext filterContext){
		 
		String flag = null;
		 
		flag = this.factory.create(filterKey).processFilters(filterContext);
		 
		return flag;
	}
}
