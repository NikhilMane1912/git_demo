package integretion;

import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import service.AppContext;

public class ConfigReader {

	public AppContext readAppContext(String configDir){
		
		AppContext context = new AppContext();
		
		InputStream inStream = XMLParser.getInputStream(configDir,XMLParser.APPCONFIG_PATH);
		
		SAXParserFactory factory = SAXParserFactory.newInstance();
		
		AppConfigHandler handler = new AppConfigHandler(context);
		
		//创建解析器
		try {
			SAXParser parser = factory.newSAXParser();
			parser.parse(inStream, handler);
			inStream.close();
			
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return context;
	}
	
	
	public AppContext readBizContext(String configDir,AppContext context){
		InputStream inStream = XMLParser.getInputStream(configDir,XMLParser.BIZCONFIG_PATH);
		
		SAXParserFactory factory = SAXParserFactory.newInstance();
		
		BizConfigHandler handler = new BizConfigHandler(context);
		
		//创建解析器
		try {
			SAXParser parser = factory.newSAXParser();
			parser.parse(inStream, handler);
			inStream.close();
			
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return context;
	}
}
