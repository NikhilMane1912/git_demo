package bussiness.validator;

import java.util.HashMap;

public abstract class AbstractValidatorFactory {

	private HashMap<String,ValidatorIf> validatorMap = 
				new HashMap<String,ValidatorIf>();
	
	public ValidatorIf create(String validatorName,boolean isCached){
		ValidatorIf validator = null;
		
		if(isCached){
			if(validatorMap.containsKey(validatorName)){
				return validatorMap.get(validatorName);
			}
			else{
				synchronized(validatorMap){
					if(validatorMap.containsKey(validatorName)){
						return validatorMap.get(validatorName);
					}
					validator = create(validatorName);
					if(validator==null){
						System.out.println("create validator fail!");
					}
					validatorMap.put(validatorName, validator);
				}
			}
			
		}
		else{
			validator = create(validatorName);
		}
		return validator;
	}
	
	protected abstract ValidatorIf create(String validatorName);
}
