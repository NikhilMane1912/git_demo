package integretion.model;

public class FactoryInfo {

	private String className;
	private String type;
	private boolean cached;
	 
	 public FactoryInfo(String theClassName, String theType, boolean isCached) {
		 this.className = theClassName;
		 this.type = theType;
		 this.cached = isCached;
	 }
	 
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public boolean isCached() {
		return cached;
	}
	public void setCached(boolean cached) {
		this.cached = cached;
	}
	 
	 
	    
}
