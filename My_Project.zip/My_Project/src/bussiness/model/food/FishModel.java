package bussiness.model.food;

public class FishModel extends AbstractFood{

	public FishModel(String name,double price){
		super(name,price);
	}
	


	@Override
	public String getUsage() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void setUsage(String s) {
		// TODO Auto-generated method stub
		
	}

}
