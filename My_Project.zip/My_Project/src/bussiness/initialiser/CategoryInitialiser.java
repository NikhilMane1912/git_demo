package bussiness.initialiser;

import bussiness.model.CategoryModel;
import service.BusinessContext;
import service.StateMgr;

public class CategoryInitialiser extends BaseInitialiser{

	@Override
	public void initialise(StateMgr mgr) {
		BusinessContext context = mgr.getBusinessContext();
		CategoryModel categoryModel = context.getCategoryModel();
		if(categoryModel==null){
			categoryModel = new CategoryModel();
			initCategoryModel(categoryModel);
		}
		context.setCategoryModel(categoryModel);
	}
	
	
	public void initCategoryModel(CategoryModel categoryModel){
		categoryModel.addProductType("Food");
		categoryModel.addProductType("Drink");
		categoryModel.addProductType("Toy");
	}
}
