package bussiness.processor;

import bussiness.model.CategoryModel;
import service.StateMgr;
import service.to.CategoryTO;

public class CategoryProcessor extends BaseProcessor{

	@Override
	protected void populateBeanFromModel(StateMgr mgr) {
		CategoryModel model = mgr.getBusinessContext().getCategoryModel();
		
		CategoryTO to = (CategoryTO)createBean(mgr);
		
		to.setProductTypes(model.getProductTypes());
		to.setSelectedType(model.getSelectedType());
		mgr.setTransferObject(to);
	}

	@Override
	protected void populateModelFromBean(StateMgr mgr) {
		CategoryTO to = (CategoryTO)mgr.getTransferObject();
		CategoryModel model = mgr.getBusinessContext().getCategoryModel();
		model.setProductTypes(to.getProductTypes());
		model.setSelectedType(to.getSelectedType());
	}

}
