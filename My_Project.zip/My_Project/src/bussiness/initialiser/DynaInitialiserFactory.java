package bussiness.initialiser;

public class DynaInitialiserFactory  extends AbstractDynaInitialiserFactory{

}
