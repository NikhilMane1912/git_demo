package presentation.filter.postRequest;

import presentation.filter.AbstractFilter;
import presentation.filter.FilterContext;
import service.to.BaseTO;

public class TransferObjPostFilter extends AbstractFilter{

	@Override
	public String process(FilterContext filterContext) {
		BaseTO to = filterContext.retriveStateMgr().getTransferObject();
		
		setTransferObjToSession(to,filterContext);
		return null;
	}

	private void setTransferObjToSession(BaseTO to, FilterContext filterContext){
		
		if (null != to) {
            filterContext.getRequest().getSession().setAttribute("TransferObject", to);
        }
	}
}
