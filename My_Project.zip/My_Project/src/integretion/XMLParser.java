package integretion;

import java.io.InputStream;

public class XMLParser {

	static String APPCONFIG_PATH = "appConfig.xml";
	static String BIZCONFIG_PATH = "bizConfig.xml";
	
	public static InputStream getInputStream(String filePath,String fileName){
		InputStream inputStream = 
				XMLParser.class.getResourceAsStream(filePath+fileName);
		return inputStream;
	}
	
}
