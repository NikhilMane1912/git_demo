package bussiness.initialiser;

import bussiness.model.UserProfileModel;
import service.BusinessContext;
import service.StateMgr;

public class UserProfileInitialiser extends BaseInitialiser{

	@Override
	public void initialise(StateMgr mgr) {
		BusinessContext context = mgr.getBusinessContext();
		UserProfileModel userProfile = context.getUserProfile();
		if(userProfile==null){
			userProfile = new UserProfileModel();
		}
		context.setUserProfile(userProfile);
	}

}
