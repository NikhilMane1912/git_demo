package bussiness.dispatcher;

import java.util.ArrayList;

import presentation.Constants;

import service.StateMgr;

public abstract class AbstractBaseFlowCtrl implements FlowCtrlIf{

	
	// instance field ---------------------------------
	protected ArrayList<String> screenFlow = null;
	
	protected String branchID = null;
    protected String currentMainID = null;
    
    // constructor
    protected void AbstractBaseFlowCtrl(){
    	initialise();
    }
    
    
    // Method	---------------------------------
	public String getBranchID() {
		return branchID;
	}
	public void setBranchID(String branchID) {
		this.branchID = branchID;
	}
	public String getCurrentMainID() {
		return currentMainID;
	}
	public void setCurrentMainID(String currentMainID) {
		this.currentMainID = currentMainID;
	}
	
	@Override
	public void initialise() {
		this.screenFlow = new ArrayList<String>();
		screenFlow.add(Constants.USERPROFILE);
		screenFlow.add(Constants.SUPPLEMENT);
		screenFlow.add(Constants.CATEGORY);
		screenFlow.add(Constants.PAYMENT);
	}
	
	
	/**
    * 	Gets the first ID within the current workflow.
    */
	@Override
	public String getFirstID() {
		String firstID = null;
		if(!this.screenFlow.isEmpty()){
			firstID = getScreenIDWithIndex(0);
		}
		return firstID;
	}
	
	
	/**
     * Gets the next ID within the flow
     */
	@Override
	public String getNextID(String currentID, StateMgr stateMgr) {
		/*
		 *  the flow will be changed while bussiness required!
		 */
		if(isScreenFlowUpdatedRequired(currentID)){
			updateScreenFlow(stateMgr);
		}
		
		String nextID = null;
		
		if(!this.screenFlow.isEmpty()){
			int index = getIndexWithScreenID(currentID);
			if(index < this.screenFlow.size()-1){
				index++;
				nextID = getScreenIDWithIndex(index);
			}
		}
		
		return nextID;
	}
	
	
	/*
	 *  This 2 method should be implements specific
	 */
	
	protected abstract boolean isScreenFlowUpdatedRequired(String CurrentID);
	
	protected abstract void updateScreenFlow(StateMgr StateMgr);
	
	
	
	
	@Override
	public String getPreviousID(String currentID, StateMgr stateMgr) {
		
		String previousID = null;
		
		if (!this.screenFlow.isEmpty()) {
			int index = getIndexWithScreenID(currentID);
			if(index>0 && index<this.screenFlow.size()){
				index--;
				previousID = getScreenIDWithIndex(index);
			}
		}
		
		return previousID;
	}
	
	
	protected String getScreenIDWithIndex(int index) {
		return this.screenFlow.get(index);
	}
    
	protected int getIndexWithScreenID(String iD) {
		return this.screenFlow.indexOf(iD);
	}


}
