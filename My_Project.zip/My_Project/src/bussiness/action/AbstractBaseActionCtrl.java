package bussiness.action;

import bussiness.helper.ObjGeneratorHelper;
import bussiness.processor.ProcessorIf;
import service.StateMgr;

public abstract class AbstractBaseActionCtrl implements ActionIf{

	private String id = null;
	public void setID(String theID) {
		this.id = theID;
	}
	public String getID(){
		return this.id;
	}
	
	
	// instance method
	protected ProcessorIf getProcessorIf(StateMgr stateMgr, String actionID){
		 return ObjGeneratorHelper.getProcessorIf(stateMgr, actionID);
	}
	
	
	
	
	
	//  abstract methods
	
	 /**
     * Initialise the action state.
     */
	public abstract void initialise(StateMgr stateMgr);
	
	
	/**
     * Process the default request that carried by the action.
     */
	public abstract void process(StateMgr stateMgr);
	
	
	/**
    * Process the alternative request that the action supported.
    */
	public abstract void processOther(StateMgr stateMgr, String operationToPerform);
	 
	
	 

   /**
    * Retrieve the action response.
    */
	public abstract void retrieve(StateMgr stateMgr);
	
	
	
	 
	 
	public boolean isSkipOnForward(StateMgr stateMgr) {
	    return false;
	}
	public boolean isSkipOnBackward(StateMgr stateMgr) {
		return false;
	}
	 
	 
}
