package integretion;

import integretion.model.FactoryInfo;
import integretion.persistence.DBConnectionFactory;

import java.util.HashMap;

import presentation.Constants;

import bussiness.action.AbstractActionFactory;
import bussiness.dispatcher.AbstractBaseDispatcher;
import bussiness.dispatcher.BackwardDispatcher;
import bussiness.dispatcher.CurrentScreenDispatcher;
import bussiness.dispatcher.FirstScreenDispatcher;
import bussiness.dispatcher.ForwardDispatcher;
import bussiness.dispatcher.NewWindowDispatcher;
import bussiness.initialiser.AbstractInitialiserFactory;
import bussiness.processor.AbstractProcessorFactory;
import bussiness.validator.AbstractValidatorFactory;

import service.AppContext;
import service.to.AbstractTOFactory;

public class AppServiceActivator {

	public AppContext initializeApplicationContext(String configPath){
		//call ConfigReader to read appconfig file
		ConfigReader configReader = new ConfigReader();
		AppContext context = configReader.readAppContext(configPath);
		
		context = configReader.readBizContext(configPath, context);
		
		initializeBusinessFactory(context);
		
		initializeDispatchMap(context);
		
		return context;
	}
	
	protected void initializeBusinessFactory(AppContext context){
		HashMap<String,FactoryInfo> map = context.getFactoryMap();
		if(map==null)
			return;
		
		context.setTOFactory(invokeTOFactory(map));
		context.setActionFactory(invokeActionFactory(map));
		context.setProcessorFactory(invokeProcessorFactory(map));
		context.setInitialiserFactory(invokeInitialiserFactory(map));
		context.setValidatorFactory(invokeValidatorFactory(map));
		context.setDBConnectionFactory(invokeDBConnectionFactory(map));
		
		
	}
	
	protected AbstractTOFactory invokeTOFactory(HashMap map){
		// to is set in appconfig.xml
		FactoryInfo info = (FactoryInfo) map.get(Constants.FACTORY_TYPE_TO);
		String className = info.getClassName();
		
		AbstractTOFactory factory = null;
		
		try {
			factory = (AbstractTOFactory)Class.forName(className).newInstance();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 	
		return factory;
	}
	
	protected AbstractActionFactory invokeActionFactory(HashMap map){
		// "action" is set in factory element of appconfig.xml
		FactoryInfo info = (FactoryInfo) map.get(Constants.FACTORY_TYPE_ACTION);
		String className = info.getClassName();
		
		AbstractActionFactory factory = null;
		try {
			factory = (AbstractActionFactory)Class.forName(className).newInstance();
		}
		catch (Exception e) {
			e.printStackTrace();
		} 	
		return factory;
	}
	
	
	protected AbstractProcessorFactory invokeProcessorFactory(HashMap map){
		// "processor" is set in factory element of appconfig.xml
		FactoryInfo info = (FactoryInfo) map.get(Constants.FACTORY_TYPE_PROCESSOR);
		String className = info.getClassName();
		
		AbstractProcessorFactory factory = null;
		try {
			factory = (AbstractProcessorFactory)Class.forName(className).newInstance();
		}
		catch (Exception e) {
			e.printStackTrace();
		} 	
		return factory;
	}
	
	protected AbstractInitialiserFactory invokeInitialiserFactory(HashMap map){
		// "initialiser" is set in factory element of appconfig.xml
		FactoryInfo info = (FactoryInfo) map.get(Constants.FACTORY_TYPE_INITIALISER);
		String className = info.getClassName();
		
		AbstractInitialiserFactory factory = null;
		try {
			factory = (AbstractInitialiserFactory)Class.forName(className).newInstance();
		}
		catch (Exception e) {
			e.printStackTrace();
		} 	
		return factory;
	}
	
	protected AbstractValidatorFactory invokeValidatorFactory(HashMap map){
		// "validator" is set in factory element of appconfig.xml
		FactoryInfo info = (FactoryInfo) map.get(Constants.FACTORY_TYPE_VALIDATOR);
		String className = info.getClassName();
		
		AbstractValidatorFactory factory = null;
		try {
			factory = (AbstractValidatorFactory)Class.forName(className).newInstance();
		}
		catch (Exception e) {
			e.printStackTrace();
		} 	
		return factory;
	}
	
	
	protected DBConnectionFactory invokeDBConnectionFactory(HashMap factoryMap){
		FactoryInfo info = (FactoryInfo) factoryMap.get(Constants.FACTORY_TYPE_DB);
		String className = info.getClassName();
		DBConnectionFactory factory = null;
		
		try{
			factory = (DBConnectionFactory)Class.forName(className).newInstance();
		}
		catch (Exception e) {
			e.printStackTrace();
		} 	
		return factory;
	}
	
	protected void initializeDispatchMap(AppContext context){
		// register dispatchers into Appcontext
		HashMap<String,AbstractBaseDispatcher> map = context.getDispatcherMap();
		map.put(Constants.DISPATCHER_FIRST_SCREEN,new FirstScreenDispatcher());
		map.put(Constants.DISPATCHER_FORWARD_SCREEN,new ForwardDispatcher());
		map.put(Constants.DISPATCHER_BACKWARD_SCREEN,new BackwardDispatcher());
		map.put(Constants.DISPATCHER_CURRENT_SCREEN,new CurrentScreenDispatcher());
		
		map.put(Constants.DISPATCHER_NEWWINDOW_SCREEN,new NewWindowDispatcher());
		
		
		
	}
	
}
