package bussiness.processor;

import bussiness.model.ProductListModel;
import service.StateMgr;
import service.to.ProductListTO;

public class ProductListProcessor extends BaseProcessor{

	@Override
	protected void populateBeanFromModel(StateMgr mgr) {
		ProductListModel model = mgr.getBusinessContext().getProductListModel();
		if(model==null){
			System.out.println("ERROR! : ProductDetailsProcessor populateBeanFromModel model==null");
			return;
		}
		
		ProductListTO to = (ProductListTO)createBean(mgr);
		to.setList(model.getList());
		to.setSelectedProduct(model.getSelectedProduct());
		mgr.setTransferObject(to);
	}

	@Override
	protected void populateModelFromBean(StateMgr mgr) {
		ProductListTO to = (ProductListTO)mgr.getTransferObject();
		ProductListModel model = mgr.getBusinessContext().getProductListModel();
		model.setList(to.getList());
		model.setSelectedProduct(to.getSelectedProduct());
	}

}
