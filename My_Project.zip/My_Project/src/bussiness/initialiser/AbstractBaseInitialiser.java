package bussiness.initialiser;

import service.StateMgr;

public abstract class AbstractBaseInitialiser implements InitialiserIf{

	 private String id = null;
	 public void setID(String id) {
	    this.id = id;
	 }
	 public String getID(){
		 return this.id;
	 }
	 
	 public abstract void initialise(StateMgr mgr);
	 
	 public abstract void initialiseOther(StateMgr mgr, String initialiseOtherID);
	 
	 
}
