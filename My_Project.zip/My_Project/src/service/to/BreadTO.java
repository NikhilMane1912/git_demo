package service.to;

public class BreadTO extends AbstractProductTO{

	private String uasge = null;

	public String getUsage() {
		return uasge;
	}

	public void setUsage(String ausage) {
		this.uasge = ausage;
	}
}
