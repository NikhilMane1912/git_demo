package presentation.filter.preRequest;

import presentation.filter.AbstractFilter;
import presentation.filter.FilterContext;

public class DBConnectionsPreFilter extends AbstractFilter{

	@Override
	public String process(FilterContext filterContext) {
		
		filterContext.retriveStateMgr().getDBConnectionMgr().initConnections(filterContext.retriveStateMgr());
		return null;
	}

}
