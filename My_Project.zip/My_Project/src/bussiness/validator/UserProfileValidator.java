package bussiness.validator;

import service.StateMgr;
import service.to.UserProfileTO;

public class UserProfileValidator extends BaseValidator{

	@Override
	public void validate(StateMgr mgr) {
		UserProfileTO to = (UserProfileTO)mgr.getBusinessContext().getBaseTO();
		
		
		
	}

	@Override
	public void validateOther(StateMgr mgr, String validatorOtherID) {
		// TODO Auto-generated method stub
		
	}
	
	
	public boolean checkUserAccountExsit(UserProfileTO to){
		
		
		return false;
	}

}
