package bussiness.dispatcher;

import bussiness.action.ActionIf;
import bussiness.helper.ObjGeneratorHelper;
import service.StateMgr;


/**
 * 	Dispatcher processes business requests by calling Action class 
 * 	methods in a sequential manner 
 * 
 * 	E.g. the Forward Dispatcher 
 * 		sequentially calls the process() method of the current Action, 
 * 		and calls the initialise() and retrieve() method of the next Action.
 *
 */
public abstract class AbstractBaseDispatcher {

	 /**
     * Main method to perform the dispatching of a request
     */
	 protected abstract String dispatch(StateMgr stateMgr);
	 
	 
	 
	 /**
	  * Gets the ActionIf object from the ActionFactory.
	 */
	 protected ActionIf getActionIf(StateMgr stateMgr, String actionID){
		 return ObjGeneratorHelper.getActionIf(stateMgr, actionID);
	 }
		 
	 
}
