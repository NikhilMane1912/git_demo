package bussiness.action;

import service.StateMgr;

/**
 * 	Action classes controls the SQS screen-flow and business workflow. 
 * 	It calls other classes (Processors, Aggregators, Illustrators) to 
 * 	process and coordinate business flows. 
 *
 *	one Action class serves one screen, and is tied to a specific Product ID
 *
 *	Action classes provide interface methods to initialise, process and 
 *	retrieve information for screens. It also provides the processOther 
 *	method for customised operations, and has custom checking for 
 *	moving forward / backward through various screens.
 */
public interface ActionIf {

	void initialise(StateMgr stateMgr);
	
	void process(StateMgr stateMgr);
	
	void processOther(StateMgr stateMgr, String operationToPerform);
	 
	void retrieve(StateMgr stateMgr);
	
	void setID(String theID);
	String getID();
	
	
	public boolean isSkipOnForward(StateMgr stateMgr);
	public boolean isSkipOnBackward(StateMgr stateMgr);
	 
	 
}
