package presentation.filter;

public abstract class AbstractFilter {
	 
	static boolean isStoreStateMgrInSession = true;
	
	public abstract String process(FilterContext filterContext);
	
	public boolean isStoreStateMgrInSession(){
		return isStoreStateMgrInSession;
	}
	 
}
