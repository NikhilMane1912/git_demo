package service.to;

import java.util.ArrayList;

public class CategoryTO extends BaseTO{

	private ArrayList<String> ProductTypes;
	private String selectedType = null;
	
	public ArrayList<String> getProductTypes() {
		return ProductTypes;
	}
	public void setProductTypes(ArrayList<String> productTypes) {
		ProductTypes = productTypes;
	}
	
	
	public String getSelectedType() {
		return selectedType;
	}
	public void setSelectedType(String selectedType) {
		this.selectedType = selectedType;
	}
	
	
	
	
	
	
}
