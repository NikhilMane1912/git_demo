package bussiness.processor;

import java.util.HashMap;

public abstract class AbstractProcessorFactory {

	private HashMap<String,ProcessorIf> processorMap = 
			new HashMap<String,ProcessorIf>(); 
	
	public ProcessorIf create(String processorName,boolean isCached){
		ProcessorIf processor = null;
		
		if(isCached){
			if(processorMap.containsKey(processorName)){
				return processorMap.get(processorName);
			}
			else{
				synchronized(processorMap){
					if(processorMap.containsKey(processorName)){
						return processorMap.get(processorName);
					}
					else{
						processor = create(processorName);
						
						if(processor==null){
							System.out.println("create ProcessorIf error!");
							return null;
						}
						processorMap.put(processorName, processor);
					}
				}
			}
		}
		else{
			
		}
		return processor;
	}
	
	
	protected abstract ProcessorIf create(String processorName);
	
}
