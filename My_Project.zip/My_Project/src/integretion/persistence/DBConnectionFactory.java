package integretion.persistence;

import integretion.model.DataSourceInfo;

import java.sql.Connection;

public class DBConnectionFactory {

	
	  //~~~~~~~~ Methods ~~~~~~~~
	
	 /**
     * Create a connection object.
     */
	 public Connection createConnection(DataSourceInfo dsInfo){
		 Connection result = null;
	     String type = dsInfo.getType();
	     
	     if("JDBC".equals(type)){
	    	 result = createJDBCConnection(dsInfo);
	     }else if("JNDI".equals(type)){
	    	 result = createJNDIConnection(dsInfo);
	     }
	     
	     return result;
	 }
	 
	 
	 /**
	 * Create a DB Accessor object.
	 */
	 protected DBAccessor createDBAccessor(DataSourceInfo dsInfo){
		 DBAccessor result = null;
		 
		 // assume the dsInfo is not null!
		 result = new DBAccessor(createConnection(dsInfo));
		 
		 return result;
	 }
	 
	 
	 /**
	 * Create connection via JDBC mechanism.
	 */
	 protected static Connection createJDBCConnection(DataSourceInfo dsInfo){
		 ConnectionHandlerIf handler = new JDBCConnectionHandler(dsInfo);
		 return handler.getConnection();
		 
	 }
	 
	 
	 /**
	 * Create connection via JNDI mechanism.
	 */
	 protected static Connection createJNDIConnection(DataSourceInfo dsInfo){
		 ConnectionHandlerIf handler = null;
		 return handler.getConnection();
	 }
}
